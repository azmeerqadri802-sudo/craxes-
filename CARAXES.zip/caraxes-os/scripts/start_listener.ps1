param(
    [string]$ModelPath = $env:CARAXES_VOSK_MODEL
)

$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$ListenerScript = Join-Path $PSScriptRoot 'wake_listener.py'
$PidFile = Join-Path $PSScriptRoot 'wake_listener.pid'
$StdoutLog = Join-Path $PSScriptRoot 'wake_listener.stdout.log'
$StderrLog = Join-Path $PSScriptRoot 'wake_listener.stderr.log'

if ([string]::IsNullOrWhiteSpace($ModelPath) -or -not (Test-Path -LiteralPath $ModelPath -PathType Container)) {
    throw 'Pass -ModelPath or set CARAXES_VOSK_MODEL to an unpacked Vosk model directory.'
}

if (Test-Path -LiteralPath $PidFile) {
    $ExistingId = 0
    [void][int]::TryParse((Get-Content -LiteralPath $PidFile -Raw), [ref]$ExistingId)
    if ($ExistingId -gt 0) {
        $Existing = Get-CimInstance Win32_Process -Filter "ProcessId = $ExistingId" -ErrorAction SilentlyContinue
        if ($Existing -and $Existing.CommandLine -like '*wake_listener.py*') {
            Write-Output "CARAXES wake listener is already running (PID $ExistingId)."
            exit 0
        }
    }
    Remove-Item -LiteralPath $PidFile -Force
}

$VenvPython = Join-Path $Root '.venv\Scripts\python.exe'
$Python = if (Test-Path -LiteralPath $VenvPython) { $VenvPython } else { (Get-Command python.exe -ErrorAction Stop).Source }
$env:CARAXES_VOSK_MODEL = (Resolve-Path -LiteralPath $ModelPath).Path
$Arguments = @('-u', ('"' + $ListenerScript + '"'))
$Process = Start-Process -FilePath $Python -ArgumentList $Arguments -WorkingDirectory $Root -WindowStyle Hidden -PassThru -RedirectStandardOutput $StdoutLog -RedirectStandardError $StderrLog
Set-Content -LiteralPath $PidFile -Value $Process.Id -NoNewline
Write-Output "CARAXES wake listener started in the background (PID $($Process.Id)). Logs: $StdoutLog and $StderrLog"
