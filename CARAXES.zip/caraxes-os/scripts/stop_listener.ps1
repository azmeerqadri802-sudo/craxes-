$ErrorActionPreference = 'Stop'
$PidFile = Join-Path $PSScriptRoot 'wake_listener.pid'
if (-not (Test-Path -LiteralPath $PidFile)) {
    Write-Output 'No CARAXES wake-listener PID file was found.'
    exit 0
}

$ProcessId = 0
[void][int]::TryParse((Get-Content -LiteralPath $PidFile -Raw), [ref]$ProcessId)
if ($ProcessId -le 0) {
    Remove-Item -LiteralPath $PidFile -Force
    throw 'The listener PID file is invalid.'
}

$Process = Get-CimInstance Win32_Process -Filter "ProcessId = $ProcessId" -ErrorAction SilentlyContinue
if ($Process -and $Process.CommandLine -like '*wake_listener.py*') {
    Stop-Process -Id $ProcessId -Force
    Write-Output "Stopped CARAXES wake listener (PID $ProcessId)."
} else {
    Write-Output 'The listener process is not running.'
}
Remove-Item -LiteralPath $PidFile -Force
