"""Offline Vosk wake-word listener for CARAXES desktop commands."""

from __future__ import annotations

import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import numpy as np
import sounddevice as sd
from vosk import KaldiRecognizer, Model


API_BASE = os.environ.get("CARAXES_API_BASE", "http://127.0.0.1:8765").rstrip("/")
_BUNDLE_ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))
_CONFIGURED_MODEL = os.environ.get("CARAXES_VOSK_MODEL")
MODEL_DIR = Path(_CONFIGURED_MODEL).expanduser() if _CONFIGURED_MODEL else _BUNDLE_ROOT / "models" / "vosk-model-small-en-us-0.15"
SAMPLE_RATE = 16000
BLOCK_SIZE = 4000  # 250 ms at the Vosk model sample rate
WAKE_PATTERN = re.compile(r"\bdra\s*[ck]\s*(?:a|e)\s*r\s*(?:y|i|u)\s*s\b", flags=re.IGNORECASE)
COMMAND_WINDOW_SECONDS = 9
SILENCE_AFTER_SPEECH_SECONDS = 1.35


def _candidate_input_devices() -> list[tuple[int | None, str, list[int]]]:
    """List working microphone candidates; don't assume the Windows default is usable."""
    try:
        devices = sd.query_devices()
    except Exception as exc:
        raise RuntimeError(f"Windows could not enumerate audio devices: {exc}") from exc
    if isinstance(devices, dict):
        devices = [devices]
    try:
        default_device = sd.default.device[0]
    except Exception:
        default_device = None
    try:
        default_device = int(default_device) if default_device is not None and int(default_device) >= 0 else None
    except (TypeError, ValueError):
        default_device = None

    records: list[tuple[int | None, str, list[int]]] = []
    for index, device in enumerate(devices):
        try:
            if int(device.get("max_input_channels", 0)) < 1:
                continue
            name = str(device.get("name", f"Audio input {index}"))
            preferred = int(round(float(device.get("default_samplerate", SAMPLE_RATE))))
        except (TypeError, ValueError):
            continue
        rates = list(dict.fromkeys([SAMPLE_RATE, preferred, 48000, 44100, 32000, 22050]))
        records.append((index, name, rates))
    records.sort(key=lambda item: item[0] != default_device)
    if not records:
        raise RuntimeError("No microphone input device is available. Connect or enable a microphone in Windows Sound Settings.")
    return records


def open_microphone() -> tuple[sd.RawInputStream, int, str]:
    """Open the first working input, accepting common native rates and resampling for Vosk."""
    failures: list[str] = []
    for device_index, device_name, sample_rates in _candidate_input_devices():
        for sample_rate in sample_rates:
            stream = None
            try:
                sd.check_input_settings(device=device_index, channels=1, samplerate=sample_rate, dtype="int16")
                stream = sd.RawInputStream(
                    device=device_index,
                    samplerate=sample_rate,
                    blocksize=max(1, round(sample_rate * BLOCK_SIZE / SAMPLE_RATE)),
                    dtype="int16",
                    channels=1,
                )
                stream.start()
                return stream, sample_rate, device_name
            except Exception as exc:
                failures.append(f"{device_name} at {sample_rate} Hz: {exc}")
                if stream is not None:
                    try:
                        stream.close()
                    except Exception:
                        pass
    explanation = "; ".join(failures[-4:])
    raise RuntimeError(f"No usable microphone stream could be opened. Check Windows microphone privacy and default input device. {explanation[:700]}")


def _read_model_audio(stream: sd.RawInputStream, input_rate: int) -> tuple[bytes, bool]:
    input_frames = max(1, round(input_rate * BLOCK_SIZE / SAMPLE_RATE))
    audio, overflowed = stream.read(input_frames)
    samples = np.frombuffer(audio, dtype=np.int16)
    if input_rate != SAMPLE_RATE and samples.size:
        output_count = max(1, round(samples.size * SAMPLE_RATE / input_rate))
        positions = np.linspace(0, samples.size - 1, output_count)
        samples = np.interp(positions, np.arange(samples.size), samples.astype(np.float32)).astype(np.int16)
    return samples.tobytes(), overflowed


def post_json(path: str, body: dict) -> dict:
    request = urllib.request.Request(
        f"{API_BASE}{path}",
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=3) as response:
        return json.loads(response.read().decode("utf-8"))


def set_listener_status(status: str, error: str | None = None) -> None:
    try:
        post_json("/api/listener/status", {"status": status, "error": error[:280] if error else None})
    except (urllib.error.URLError, TimeoutError):
        pass


def capture_one_command(stream: sd.RawInputStream, model: Model, input_rate: int = SAMPLE_RATE) -> str:
    recognizer = KaldiRecognizer(model, SAMPLE_RATE)
    started = time.monotonic()
    last_voice = started
    speech_seen = False
    final_segments: list[str] = []

    while time.monotonic() - started < COMMAND_WINDOW_SECONDS:
        audio, overflowed = _read_model_audio(stream, input_rate)
        if overflowed:
            print("[audio] input buffer overrun; continuing", file=sys.stderr)
        samples = np.frombuffer(audio, dtype=np.int16)
        rms = float(np.sqrt(np.mean(samples.astype(np.float32) ** 2))) if samples.size else 0.0
        now = time.monotonic()
        if rms > 380:
            speech_seen = True
            last_voice = now

        if recognizer.AcceptWaveform(audio):
            phrase = json.loads(recognizer.Result()).get("text", "").strip()
            if phrase:
                final_segments.append(phrase)
                if speech_seen:
                    last_voice = now

        if speech_seen and now - last_voice >= SILENCE_AFTER_SPEECH_SECONDS:
            break

    tail = json.loads(recognizer.FinalResult()).get("text", "").strip()
    if tail:
        final_segments.append(tail)
    return " ".join(final_segments).strip()


def run() -> bool:
    set_listener_status("starting")
    try:
        if not (MODEL_DIR / "am" / "final.mdl").is_file():
            raise FileNotFoundError(
                f"Offline Vosk speech model is missing or incomplete at {MODEL_DIR}. Reinstall CARAXES with the included Windows wake model."
            )
        print(f"Loading offline speech model from {MODEL_DIR} …")
        model = Model(str(MODEL_DIR))
        wake_recognizer = KaldiRecognizer(model, SAMPLE_RATE)
        print("Listening for ‘Dracarys’. Press Ctrl+C to stop.")

        stream, input_rate, device_name = open_microphone()
        print(f"Microphone ready: {device_name} at {input_rate} Hz (resampling to {SAMPLE_RATE} Hz for Vosk).")
        try:
            set_listener_status("online")
            next_heartbeat = 0.0
            while True:
                audio, overflowed = _read_model_audio(stream, input_rate)
                now = time.monotonic()
                if now >= next_heartbeat:
                    try:
                        post_json("/api/listener/heartbeat", {})
                    except (urllib.error.URLError, TimeoutError):
                        pass
                    next_heartbeat = now + 5.0
                if overflowed:
                    print("[audio] input buffer overrun; continuing", file=sys.stderr)
                # Vosk emits final utterances after a pause; detect the trigger
                # there to avoid waking on a transient partial-word match.
                if not wake_recognizer.AcceptWaveform(audio):
                    continue
                phrase = json.loads(wake_recognizer.Result()).get("text", "").strip()
                wake_recognizer = KaldiRecognizer(model, SAMPLE_RATE)
                if not WAKE_PATTERN.search(phrase):
                    continue

                print("[CARAXES] Dracarys recognized — core awakened.")
                try:
                    post_json("/api/wake", {"source": "offline-vosk"})
                except (urllib.error.URLError, TimeoutError) as exc:
                    print(f"[CARAXES] Core is unavailable at {API_BASE}: {exc}", file=sys.stderr)
                    continue

                command = capture_one_command(stream, model, input_rate)
                if not command:
                    print("[CARAXES] No command heard; returning to wake-word standby.")
                    continue
                print(f"[CARAXES] Heard: {command}")
                try:
                    response = post_json("/api/command", {"text": command})
                    print(f"[CARAXES] {response.get('message', 'Command handled.')}")
                except (urllib.error.URLError, TimeoutError) as exc:
                    print(f"[CARAXES] Command service unavailable: {exc}", file=sys.stderr)
                wake_recognizer = KaldiRecognizer(model, SAMPLE_RATE)
        finally:
            try:
                stream.stop()
            finally:
                stream.close()
    except KeyboardInterrupt:
        print("\nWake listener stopped.")
        return True
    except Exception as exc:
        set_listener_status("offline", f"{type(exc).__name__}: {exc}")
        print(f"Audio listener failed: {exc}", file=sys.stderr)
        return False


if __name__ == "__main__":
    run()
