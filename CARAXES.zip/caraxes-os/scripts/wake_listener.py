"""Offline Vosk wake-word listener for CARAXES.

The recognizer only looks for the configured wake phrase, then forwards one
short command to the local, capability-limited FastAPI service.
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import numpy as np
import sounddevice as sd
from vosk import KaldiRecognizer, Model


API_BASE = os.environ.get("CARAXES_API_BASE", "http://127.0.0.1:8765").rstrip("/")
MODEL_DIR = Path(os.environ.get("CARAXES_VOSK_MODEL", "")).expanduser()
SAMPLE_RATE = 16000
BLOCK_SIZE = 4000  # 250 ms
WAKE_PATTERN = re.compile(r"\bdra\s*[ck]\s*(?:a|e)\s*r\s*(?:y|i|u)\s*s\b", flags=re.IGNORECASE)
COMMAND_WINDOW_SECONDS = 9
SILENCE_AFTER_SPEECH_SECONDS = 1.35


def post_json(path: str, body: dict) -> dict:
    request = urllib.request.Request(
        f"{API_BASE}{path}",
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=3) as response:
        return json.loads(response.read().decode("utf-8"))


def set_listener_status(status: str, error: str | None = None) -> None:
    try:
        post_json("/api/listener/status", {"status": status, "error": error})
    except (urllib.error.URLError, TimeoutError):
        pass


def capture_one_command(stream: sd.RawInputStream, model: Model) -> str:
    recognizer = KaldiRecognizer(model, SAMPLE_RATE)
    started = time.monotonic()
    last_voice = started
    speech_seen = False
    final_segments: list[str] = []

    while time.monotonic() - started < COMMAND_WINDOW_SECONDS:
        audio, overflowed = stream.read(BLOCK_SIZE)
        if overflowed:
            print("[audio] input buffer overrun; continuing", file=sys.stderr)
        samples = np.frombuffer(audio, dtype=np.int16)
        rms = float(np.sqrt(np.mean(samples.astype(np.float32) ** 2))) if samples.size else 0.0
        now = time.monotonic()
        if rms > 380:
            speech_seen = True
            last_voice = now

        if recognizer.AcceptWaveform(audio):
            phrase = json.loads(recognizer.Result()).get("text", "").strip()
            if phrase:
                final_segments.append(phrase)
                if speech_seen:
                    last_voice = now

        if speech_seen and now - last_voice >= SILENCE_AFTER_SPEECH_SECONDS:
            break

    tail = json.loads(recognizer.FinalResult()).get("text", "").strip()
    if tail:
        final_segments.append(tail)
    return " ".join(final_segments).strip()


def run() -> bool:
    set_listener_status("starting")
    try:
        if not MODEL_DIR.is_dir():
            raise FileNotFoundError(
                f"Offline speech model was not found: {MODEL_DIR or 'CARAXES_VOSK_MODEL is unset'}"
            )
        print(f"Loading offline speech model from {MODEL_DIR} …")
        model = Model(str(MODEL_DIR))
        wake_recognizer = KaldiRecognizer(model, SAMPLE_RATE)
        print("Listening for ‘Dracarys’. Press Ctrl+C to stop.")

        with sd.RawInputStream(
            samplerate=SAMPLE_RATE,
            blocksize=BLOCK_SIZE,
            dtype="int16",
            channels=1,
        ) as stream:
            set_listener_status("online")
            next_heartbeat = 0.0
            while True:
                audio, overflowed = stream.read(BLOCK_SIZE)
                now = time.monotonic()
                if now >= next_heartbeat:
                    try:
                        post_json("/api/listener/heartbeat", {})
                    except (urllib.error.URLError, TimeoutError):
                        pass
                    next_heartbeat = now + 5.0
                if overflowed:
                    print("[audio] input buffer overrun; continuing", file=sys.stderr)
                # Vosk emits final utterances after a pause; detect the trigger
                # there to avoid waking on a transient partial-word match.
                if not wake_recognizer.AcceptWaveform(audio):
                    continue
                phrase = json.loads(wake_recognizer.Result()).get("text", "").strip()
                wake_recognizer = KaldiRecognizer(model, SAMPLE_RATE)
                if not WAKE_PATTERN.search(phrase):
                    continue

                print("[CARAXES] Dracarys recognized — core awakened.")
                try:
                    post_json("/api/wake", {"source": "offline-vosk"})
                except (urllib.error.URLError, TimeoutError) as exc:
                    print(f"[CARAXES] Core is unavailable at {API_BASE}: {exc}", file=sys.stderr)
                    continue

                command = capture_one_command(stream, model)
                if not command:
                    print("[CARAXES] No command heard; returning to wake-word standby.")
                    continue
                print(f"[CARAXES] Heard: {command}")
                try:
                    response = post_json("/api/command", {"text": command})
                    print(f"[CARAXES] {response.get('message', 'Command handled.')}")
                except (urllib.error.URLError, TimeoutError) as exc:
                    print(f"[CARAXES] Command service unavailable: {exc}", file=sys.stderr)
                wake_recognizer = KaldiRecognizer(model, SAMPLE_RATE)
    except KeyboardInterrupt:
        print("\nWake listener stopped.")
        return True
    except Exception as exc:
        set_listener_status("offline", f"{type(exc).__name__}: {exc}")
        print(f"Audio listener failed: {exc}", file=sys.stderr)
        return False


if __name__ == "__main__":
    run()
