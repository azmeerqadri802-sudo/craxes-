"""Register or remove CARAXES background startup for the current Windows user."""

from __future__ import annotations

import argparse
import platform
import sys
from pathlib import Path


RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
VALUE_NAME = "CARAXES"


def pythonw_executable() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable)
    executable = Path(sys.executable)
    candidate = executable.with_name("pythonw.exe")
    return candidate if candidate.is_file() else executable


def set_autostart(enable: bool, port: int = 8765) -> None:
    if platform.system() != "Windows":
        raise RuntimeError("CARAXES boot auto-start setup is supported on Windows only.")
    import winreg

    with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
        if enable:
            root = Path(__file__).resolve().parents[1]
            if getattr(sys, "frozen", False):
                desktop_entry = f"--background --port {port}"
            else:
                desktop_entry = f'"{root / "desktop.py"}" --background --port {port}'
            command = f'"{pythonw_executable()}" {desktop_entry}'
            winreg.SetValueEx(key, VALUE_NAME, 0, winreg.REG_SZ, command)
        else:
            try:
                winreg.DeleteValue(key, VALUE_NAME)
            except FileNotFoundError:
                pass


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--enable", action="store_true", help="Start CARAXES listener and local API when this user signs in.")
    group.add_argument("--disable", action="store_true", help="Remove the CARAXES current-user startup registration.")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("--port must be between 1024 and 65535.")
    try:
        set_autostart(args.enable, args.port)
    except (OSError, RuntimeError) as exc:
        print(f"Could not update CARAXES auto-start: {exc}", file=sys.stderr)
        return 1
    print("CARAXES startup enabled for this Windows user." if args.enable else "CARAXES startup disabled.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
