"""CARAXES background scripts packaged with the desktop app."""
