import * as THREE from 'three';
import './style.css';

const dragons = [
  ['Caraxes', 'Core brain · advanced code execution', '#a92725'],
  ['Syrax', 'Master control UI · visual dashboard', '#c29c59'],
  ['Vhagar', 'Heavy security · privacy shields', '#617c69'],
  ['Balerion', 'System automation · root macros', '#746a6e'],
  ['Meleys', 'Speed optimization · performance', '#b34b3d'],
  ['Vermithor', 'Database vault · local retrieval', '#b69a65'],
  ['Silverwing', 'UI/UX aesthetics · dynamic themes', '#8f9aa0'],
  ['Seasmoke', 'Network · APIs · web hooks', '#8babb1'],
  ['Sunfyre', 'Media rendering · graphics pipeline', '#d18a42'],
  ['Dreamfyre', 'AI prompt processor · context', '#829bab'],
  ['Vermax', 'Task scheduler · reminders', '#7f986c'],
  ['Arrax', 'Encryption guard · privacy filters', '#b2c4c8'],
  ['Tyraxes', 'File management · organization', '#aa835a'],
  ['Moondancer', 'Voice · audio synchronization', '#9aa1a8'],
  ['The Cannibal', 'Garbage collection · cleanup', '#6f654f'],
  ['Tessarion', 'Adobe Creative Cloud · blue queen', '#3f81cf'],
].map(([name, role, color], index) => ({ name, role, color, index }));

const $ = (selector) => document.querySelector(selector);
const voiceToggle = $('#voice-toggle');
const canSpeak = 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;
let voiceRepliesEnabled = localStorage.getItem('caraxesVoiceReplies') !== 'off';

function updateVoiceToggle() {
  voiceToggle.disabled = !canSpeak;
  voiceToggle.setAttribute('aria-pressed', String(canSpeak && voiceRepliesEnabled));
  voiceToggle.textContent = canSpeak ? `VOICE ${voiceRepliesEnabled ? 'ON' : 'OFF'}` : 'VOICE UNAVAILABLE';
  voiceToggle.title = canSpeak
    ? voiceRepliesEnabled ? 'Mute spoken replies' : 'Speak command replies aloud'
    : 'Speech output is unavailable in this WebView.';
}

async function speakReply(message, language = 'en') {
  if (!canSpeak || !voiceRepliesEnabled || !message) return;
  window.speechSynthesis.cancel();
  let profile = { voice_language: language?.startsWith('ur') ? 'ur-PK' : 'en-US', rate: 0.96, pitch: 0.9 };
  try {
    const prepared = await fetch('/moondancer/prepare', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: String(message).slice(0, 12000), language }),
    });
    if (prepared.ok) profile = { ...profile, ...await prepared.json() };
  } catch { /* Browser speech remains available if the local voice profile route is offline. */ }
  if (!voiceRepliesEnabled) return;
  const utterance = new SpeechSynthesisUtterance(String(profile.text || message).slice(0, 12000));
  utterance.lang = profile.voice_language || 'en-US';
  utterance.rate = profile.rate ?? 0.96;
  utterance.pitch = profile.pitch ?? 0.9;
  const languagePrefix = utterance.lang.toLowerCase().split('-')[0];
  const matchingVoice = window.speechSynthesis.getVoices().find((voice) => voice.lang.toLowerCase().startsWith(languagePrefix));
  if (matchingVoice) utterance.voice = matchingVoice;
  window.speechSynthesis.speak(utterance);
}

voiceToggle.addEventListener('click', () => {
  voiceRepliesEnabled = !voiceRepliesEnabled;
  localStorage.setItem('caraxesVoiceReplies', voiceRepliesEnabled ? 'on' : 'off');
  if (!voiceRepliesEnabled && canSpeak) window.speechSynthesis.cancel();
  updateVoiceToggle();
});
updateVoiceToggle();

const list = $('#dragon-list');
list.innerHTML = dragons.map((dragon) => `
  <button class="dragon-row" data-index="${dragon.index}" type="button" aria-label="${dragon.name}: ${dragon.role}">
    <span class="dragon-glyph">${String(dragon.index + 1).padStart(2, '0')}</span>
    <span class="dragon-row-copy"><b>${dragon.name}</b><small>${dragon.role.split(' · ')[0]}</small></span>
    <span class="dragon-row-state"></span>
  </button>`).join('');

let audioContext;
function wakeSound() {
  try {
    audioContext ||= new AudioContext();
    if (audioContext.state === 'suspended') audioContext.resume();
    const now = audioContext.currentTime;
    const master = audioContext.createGain();
    master.gain.setValueAtTime(0.0001, now);
    master.gain.exponentialRampToValueAtTime(0.18, now + 0.22);
    master.gain.exponentialRampToValueAtTime(0.0001, now + 1.25);
    master.connect(audioContext.destination);
    const oscillator = audioContext.createOscillator();
    oscillator.type = 'sawtooth';
    oscillator.frequency.setValueAtTime(74, now);
    oscillator.frequency.exponentialRampToValueAtTime(196, now + 0.7);
    oscillator.frequency.exponentialRampToValueAtTime(58, now + 1.2);
    oscillator.connect(master);
    oscillator.start(now);
    oscillator.stop(now + 1.25);
  } catch { /* Audio is an enhancement; the stage remains usable without it. */ }
}

function fireSound() {
  if (!audioContext || audioContext.state !== 'running') return;
  const now = audioContext.currentTime;
  const osc = audioContext.createOscillator();
  const gain = audioContext.createGain();
  const filter = audioContext.createBiquadFilter();
  osc.type = 'triangle';
  osc.frequency.setValueAtTime(165, now);
  osc.frequency.exponentialRampToValueAtTime(52, now + 0.31);
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(700, now);
  filter.frequency.exponentialRampToValueAtTime(110, now + 0.32);
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.075, now + 0.045);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.34);
  osc.connect(filter).connect(gain).connect(audioContext.destination);
  osc.start(now);
  osc.stop(now + 0.35);
}

const canvas = $('#dragon-stage');
const scene = new THREE.Scene();
scene.background = new THREE.Color('#090708');
scene.fog = new THREE.FogExp2('#090708', 0.042);
const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 90);
camera.position.set(0, 3.2, 19.5);
camera.lookAt(0, -0.15, -1.6);

let renderer;
try {
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.22;
  $('#renderer-state').textContent = 'WEBGL STAGE ONLINE';
} catch (error) {
  $('#renderer-state').textContent = 'WEBGL UNAVAILABLE';
  console.error(error);
}

scene.add(new THREE.AmbientLight('#8d7772', 1.1));
const keyLight = new THREE.PointLight('#f5d5aa', 100, 34, 2);
keyLight.position.set(1, 9, 7);
scene.add(keyLight);
const emberLight = new THREE.PointLight('#a5261e', 95, 22, 2);
emberLight.position.set(-3, 0.6, 5);
scene.add(emberLight);
const rimLight = new THREE.DirectionalLight('#8a3440', 3.2);
rimLight.position.set(-7, 4, -6);
scene.add(rimLight);

const floorMaterial = new THREE.MeshStandardMaterial({ color: '#171214', roughness: 0.78, metalness: 0.46 });
const floor = new THREE.Mesh(new THREE.CircleGeometry(13, 96), floorMaterial);
floor.rotation.x = -Math.PI / 2;
floor.position.set(0, -2.13, -1.2);
scene.add(floor);

function addRing(radius, color, opacity = 0.42, z = -1.2) {
  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(radius, 0.018, 6, 128),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity }),
  );
  ring.rotation.x = Math.PI / 2;
  ring.position.set(0, -2.095, z);
  ring.scale.set(1, 0.62, 1);
  scene.add(ring);
}
addRing(9.2, '#704339', 0.5);
addRing(6.1, '#493538', 0.42, -1.4);
addRing(3.4, '#6d382c', 0.34, -1.7);

const archMaterial = new THREE.MeshStandardMaterial({ color: '#21191b', roughness: 0.87, metalness: 0.25 });
const archAccent = new THREE.MeshBasicMaterial({ color: '#4b2425', transparent: true, opacity: 0.57 });
for (const side of [-1, 1]) {
  for (let pillar = 0; pillar < 3; pillar += 1) {
    const z = -6.8 + pillar * 2.3;
    const x = side * (8.1 - pillar * 0.36);
    const column = new THREE.Mesh(new THREE.CylinderGeometry(0.31, 0.44, 8.8, 8), archMaterial);
    column.position.set(x, 2.1, z);
    scene.add(column);
    const capital = new THREE.Mesh(new THREE.CylinderGeometry(0.54, 0.47, 0.31, 8), archAccent);
    capital.position.set(x, 6.47, z);
    scene.add(capital);
  }
}
for (let i = 0; i < 6; i += 1) {
  const arch = new THREE.Mesh(new THREE.TorusGeometry(9.3 + i * 0.32, 0.11, 7, 64, Math.PI), archMaterial);
  arch.position.set(0, 3.25 - i * 0.42, -7.5 - i * 0.17);
  arch.rotation.z = Math.PI;
  arch.scale.set(0.9, 0.79, 1);
  scene.add(arch);
}

function material(color, options = {}) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.66, metalness: 0.22, ...options });
}

function connectCylinder(group, a, b, radius, mat) {
  const start = new THREE.Vector3(...a);
  const end = new THREE.Vector3(...b);
  const direction = new THREE.Vector3().subVectors(end, start);
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.72, radius, direction.length(), 7), mat);
  mesh.position.copy(start).add(end).multiplyScalar(0.5);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.normalize());
  group.add(mesh);
  return mesh;
}

function makeWing(group, side, hide, membrane) {
  const pivot = new THREE.Group();
  group.add(pivot);
  const points = [
    [side * 0.25, 0.28, -0.03],
    [side * 0.68, 0.92, -0.10],
    [side * 1.75, 1.55, -0.24],
    [side * 1.53, 0.47, -0.28],
    [side * 1.12, 0.05, -0.23],
  ];
  const geometry = new THREE.BufferGeometry();
  const vertices = new Float32Array([
    ...points[0], ...points[1], ...points[2],
    ...points[0], ...points[2], ...points[3],
    ...points[0], ...points[3], ...points[4],
  ]);
  geometry.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
  geometry.computeVertexNormals();
  pivot.add(new THREE.Mesh(geometry, membrane));
  for (const index of [1, 2, 3, 4]) {
    const curve = new THREE.LineCurve3(new THREE.Vector3(...points[0]), new THREE.Vector3(...points[index]));
    pivot.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 1, 0.025, 5, false), hide));
  }
  return { side, pivot };
}

function buildDragon(dragon) {
  const group = new THREE.Group();
  const hide = material('#191619', { roughness: 0.54, metalness: 0.34 });
  const belly = material('#3b2d2d', { roughness: 0.84, metalness: 0.12 });
  const wingMat = material(dragon.color, { side: THREE.DoubleSide, transparent: true, opacity: 0.7, roughness: 0.9, metalness: 0.08 });
  const accent = material(dragon.color, { emissive: dragon.color, emissiveIntensity: 0.32, metalness: 0.5, roughness: 0.45 });
  const eyeMat = new THREE.MeshBasicMaterial({ color: '#ffad46' });
  const body = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 9), hide);
  body.scale.set(0.55, 0.36, 0.88);
  group.add(body);
  const chest = new THREE.Mesh(new THREE.SphereGeometry(0.43, 10, 8), belly);
  chest.position.set(0, -0.04, 0.33);
  chest.scale.set(0.63, 0.79, 1.05);
  group.add(chest);
  const neckCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0.06, 0.38), new THREE.Vector3(0, 0.18, 0.62), new THREE.Vector3(0, 0.34, 0.85), new THREE.Vector3(0, 0.32, 1.0),
  ]);
  group.add(new THREE.Mesh(new THREE.TubeGeometry(neckCurve, 7, 0.17, 7, false), hide));
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 10, 8), hide);
  head.position.set(0, 0.33, 1.04);
  head.scale.set(1.1, 0.69, 1.24);
  group.add(head);
  const snout = new THREE.Mesh(new THREE.SphereGeometry(0.19, 8, 7), belly);
  snout.position.set(0, 0.22, 1.28);
  snout.scale.set(0.75, 0.65, 1.4);
  group.add(snout);

  for (const side of [-1, 1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.039, 6, 5), eyeMat);
    eye.position.set(side * 0.19, 0.39, 1.12);
    group.add(eye);
    const horn = new THREE.Mesh(new THREE.ConeGeometry(0.105, 0.42, 5), accent);
    horn.position.set(side * 0.16, 0.59, 0.95);
    horn.rotation.z = -side * 0.47;
    horn.rotation.x = 0.18;
    group.add(horn);
    connectCylinder(group, [side * 0.35, -0.1, 0.4], [side * 0.43, -0.65, 0.59], 0.12, hide);
    const frontLeg = new THREE.Group();
    frontLeg.position.set(side * 0.43, -0.64, 0.59);
    connectCylinder(frontLeg, [0, 0.04, 0], [side * 0.025, -0.23, 0.06], 0.105, hide);
    connectCylinder(frontLeg, [side * 0.025, -0.23, 0.06], [side * 0.06, -0.3, 0.19], 0.075, belly);
    group.add(frontLeg);
    dragon.legs.push(frontLeg);
    const hindLeg = new THREE.Group();
    hindLeg.position.set(side * 0.4, -0.16, -0.45);
    connectCylinder(hindLeg, [0, 0, 0], [side * 0.09, -0.42, -0.05], 0.15, hide);
    connectCylinder(hindLeg, [side * 0.09, -0.42, -0.05], [side * 0.08, -0.51, 0.1], 0.085, belly);
    group.add(hindLeg);
    dragon.legs.push(hindLeg);
    const wing = makeWing(group, side, accent, wingMat);
    dragon.wings.push(wing);
  }

  const tailCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, -0.04, -0.62), new THREE.Vector3(0, -0.01, -1.02), new THREE.Vector3(0.14, 0.04, -1.48), new THREE.Vector3(0.32, 0.13, -1.9),
  ]);
  group.add(new THREE.Mesh(new THREE.TubeGeometry(tailCurve, 9, 0.1, 6, false), hide));
  const tailSpade = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.45, 5), accent);
  tailSpade.position.set(0.34, 0.13, -2.04);
  tailSpade.rotation.x = -Math.PI / 2;
  tailSpade.rotation.z = 0.28;
  group.add(tailSpade);

  for (let i = 0; i < 5; i += 1) {
    const spike = new THREE.Mesh(new THREE.ConeGeometry(0.078 - i * 0.006, 0.23, 5), accent);
    spike.position.set(0, 0.36, -0.48 + i * 0.25);
    spike.rotation.x = Math.PI;
    group.add(spike);
  }
  const embers = new THREE.Mesh(new THREE.SphereGeometry(0.055, 6, 5), new THREE.MeshBasicMaterial({ color: dragon.color }));
  embers.position.set(0, 0.21, 1.43);
  group.add(embers);
  group.userData.mouth = new THREE.Vector3(0, 0.21, 1.42);
  group.userData.body = body;
  group.userData.dragon = dragon;
  return group;
}

for (let index = 0; index < dragons.length; index += 1) {
  const dragon = dragons[index];
  dragon.legs = [];
  dragon.wings = [];
  const group = buildDragon(dragon);
  const column = index % 5;
  const row = Math.floor(index / 5);
  dragon.base = { x: (column - 2) * 2.65, y: -1.6 - row * 0.06, z: 0.35 - row * 2.55 };
  dragon.scale = row === 0 ? 0.55 : row === 1 ? 0.48 : 0.4;
  dragon.group = group;
  dragon.initialFired = false;
  group.position.set(dragon.base.x, dragon.base.y, dragon.base.z - 3.1);
  group.scale.setScalar(0.001);
  scene.add(group);
}

// One compact point buffer is shared by every dragon's flame burst.
const particleCount = 240;
const particlePositions = new Float32Array(particleCount * 3);
const particleColors = new Float32Array(particleCount * 3);
const particleVelocity = Array.from({ length: particleCount }, () => new THREE.Vector3());
const particleLife = new Float32Array(particleCount);
const particleMaxLife = new Float32Array(particleCount);
for (let i = 0; i < particleCount; i += 1) {
  particlePositions[i * 3 + 1] = -100;
  const warmth = Math.random();
  particleColors[i * 3] = 1;
  particleColors[i * 3 + 1] = 0.23 + warmth * 0.58;
  particleColors[i * 3 + 2] = 0.04 + warmth * 0.11;
}
const particleGeometry = new THREE.BufferGeometry();
particleGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
particleGeometry.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));
const flame = new THREE.Points(particleGeometry, new THREE.PointsMaterial({
  size: 0.48, map: makeFlameTexture(), vertexColors: true, transparent: true, opacity: 0.9,
  blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true,
}));
scene.add(flame);
let nextParticle = 0;

function makeFlameTexture() {
  const textureCanvas = document.createElement('canvas');
  textureCanvas.width = textureCanvas.height = 64;
  const ctx = textureCanvas.getContext('2d');
  const gradient = ctx.createRadialGradient(32, 32, 2, 32, 32, 32);
  gradient.addColorStop(0, 'rgba(255,250,210,1)');
  gradient.addColorStop(0.22, 'rgba(255,187,65,.95)');
  gradient.addColorStop(0.56, 'rgba(232,48,20,.5)');
  gradient.addColorStop(1, 'rgba(100,10,6,0)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 64, 64);
  const texture = new THREE.CanvasTexture(textureCanvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function burstAt(position) {
  for (let i = 0; i < 72; i += 1) {
    const particle = nextParticle;
    nextParticle = (nextParticle + 1) % particleCount;
    const offset = particle * 3;
    particlePositions[offset] = position.x + (Math.random() - 0.5) * 0.13;
    particlePositions[offset + 1] = position.y + (Math.random() - 0.5) * 0.13;
    particlePositions[offset + 2] = position.z;
    particleVelocity[particle].set((Math.random() - 0.5) * 1.45, (Math.random() - 0.25) * 1.05, 2.2 + Math.random() * 2.2);
    particleLife[particle] = 0.52 + Math.random() * 0.46;
    particleMaxLife[particle] = particleLife[particle];
  }
  particleGeometry.attributes.position.needsUpdate = true;
  fireSound();
}

function updateParticles(delta) {
  for (let i = 0; i < particleCount; i += 1) {
    if (particleLife[i] <= 0) continue;
    particleLife[i] -= delta;
    const offset = i * 3;
    if (particleLife[i] <= 0) {
      particlePositions[offset + 1] = -100;
      continue;
    }
    particleVelocity[i].y -= 0.95 * delta;
    particlePositions[offset] += particleVelocity[i].x * delta;
    particlePositions[offset + 1] += particleVelocity[i].y * delta;
    particlePositions[offset + 2] += particleVelocity[i].z * delta;
    const fade = particleLife[i] / particleMaxLife[i];
    particleColors[offset] = 1;
    particleColors[offset + 1] = 0.2 + fade * 0.58;
    particleColors[offset + 2] = 0.04 + fade * 0.15;
  }
  particleGeometry.attributes.position.needsUpdate = true;
  particleGeometry.attributes.color.needsUpdate = true;
}

let introStart = performance.now();
let previousFrame = introStart;
let lastReveal = -1;
let firedThisPass = new Set();
let introRunning = true;
const stepDuration = 0.54;
const introDuration = dragons.length * stepDuration + 0.8;

function revealDragon(index) {
  const dragon = dragons[index];
  if (!dragon) return;
  $('#reveal-index').textContent = `${String(index + 1).padStart(2, '0')} / ${String(dragons.length).padStart(2, '0')}`;
  $('#reveal-name').textContent = dragon.name.toUpperCase();
  $('#reveal-role').textContent = dragon.role.toUpperCase();
  $('#reveal').classList.remove('reveal-in');
  void $('#reveal').offsetWidth;
  $('#reveal').classList.add('reveal-in');
  list.querySelectorAll('.dragon-row').forEach((row) => row.classList.toggle('active', Number(row.dataset.index) === index));
}

function triggerIntro(withAudio = true) {
  introStart = performance.now();
  lastReveal = -1;
  firedThisPass = new Set();
  introRunning = true;
  for (const dragon of dragons) {
    dragon.initialFired = false;
    dragon.group.scale.setScalar(0.001);
  }
  $('#core-status').textContent = 'CORE AWAKENING';
  $('#reveal').classList.remove('settled');
  if (withAudio) wakeSound();
}

$('#awaken').addEventListener('click', () => triggerIntro(true));
list.addEventListener('click', (event) => {
  const row = event.target.closest('.dragon-row');
  if (!row) return;
  const dragon = dragons[Number(row.dataset.index)];
  revealDragon(dragon.index);
  list.querySelectorAll('.dragon-row').forEach((item) => item.classList.toggle('active', item === row));
});

function animate(now) {
  if (!renderer) return;
  const delta = Math.min((now - previousFrame) / 1000, 0.05);
  previousFrame = now;
  const elapsed = Math.max(0, (now - introStart) / 1000);
  const activeIndex = Math.min(dragons.length - 1, Math.floor(elapsed / stepDuration));
  if (activeIndex !== lastReveal && elapsed < introDuration) {
    lastReveal = activeIndex;
    revealDragon(activeIndex);
  }

  dragons.forEach((dragon, index) => {
    const local = (elapsed - index * stepDuration) / stepDuration;
    const progress = THREE.MathUtils.clamp(local, 0, 1);
    const eased = progress * progress * (3 - 2 * progress);
    const group = dragon.group;
    group.scale.setScalar(dragon.scale * Math.max(0.001, eased));
    group.position.x = dragon.base.x + (1 - eased) * (index % 2 === 0 ? -0.6 : 0.6);
    group.position.y = dragon.base.y + Math.sin(now * 0.0035 + index) * 0.018 + Math.sin(progress * Math.PI) * 0.12;
    group.position.z = dragon.base.z - 3.1 + eased * 3.1;
    group.rotation.y = Math.sin(now * 0.0007 + index * 0.8) * 0.045;
    group.userData.body.scale.y = 0.36 + Math.sin(now * 0.004 + index) * 0.014;
    dragon.legs.forEach((leg, legIndex) => { leg.rotation.x = Math.sin(now * 0.008 + index + legIndex * Math.PI) * 0.18 * (progress > 0.12 && progress < 0.92 ? 1 : 0.12); });
    dragon.wings.forEach((wing) => { wing.pivot.rotation.z = Math.sin(now * 0.0042 + index) * 0.105 * wing.side; });
    if (index === activeIndex && progress > 0.28 && progress < 0.55 && !firedThisPass.has(index)) {
      const mouth = group.localToWorld(group.userData.mouth.clone());
      burstAt(mouth);
      firedThisPass.add(index);
    }
  });
  updateParticles(delta);
  emberLight.intensity = 74 + Math.sin(now * 0.009) * 15;
  camera.position.x = Math.sin(now * 0.0002) * 0.22;
  camera.lookAt(0, -0.18, -1.6);
  renderer.render(scene, camera);

  if (elapsed >= introDuration && introRunning) {
    introRunning = false;
    $('#core-status').textContent = 'CORE ONLINE';
    $('#reveal').classList.add('settled');
  }
  requestAnimationFrame(animate);
}

function resize() {
  if (!renderer) return;
  const box = canvas.getBoundingClientRect();
  renderer.setSize(Math.max(1, box.width), Math.max(1, box.height), false);
  camera.aspect = box.width / Math.max(box.height, 1);
  camera.updateProjectionMatrix();
}
window.addEventListener('resize', resize);
resize();
requestAnimationFrame(animate);

function formatTime() {
  $('#clock').textContent = new Intl.DateTimeFormat(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(new Date());
}
formatTime();
setInterval(formatTime, 1000);

function updateTelemetry(data) {
  const cpu = Math.round(data.cpu_percent ?? 0);
  const memory = Math.round(data.memory_percent ?? 0);
  $('#cpu-value').textContent = `${cpu}%`;
  $('#cpu-meter').style.width = `${cpu}%`;
  $('#memory-value').textContent = `${memory}%`;
  $('#memory-meter').style.width = `${memory}%`;
  $('#memory-detail').textContent = `${data.memory_used_gb} / ${data.memory_total_gb} GB occupied`;
  if (data.battery) {
    $('#battery-value').textContent = `${Math.round(data.battery.percent)}%`;
    $('#battery-detail').textContent = data.battery.plugged ? 'Power connected' : 'Running on battery';
  } else {
    $('#battery-value').textContent = 'N/A';
    $('#battery-detail').textContent = 'No battery sensor detected';
  }
  const interfaces = data.network?.connected_interfaces || [];
  $('#network-value').textContent = interfaces.length ? 'CONNECTED' : 'OFFLINE';
  const wifi = data.wifi ? `Wi-Fi ${data.wifi.connected ? 'connected' : data.wifi.available ? 'disconnected' : 'unavailable'}` : '';
  $('#network-detail').textContent = [wifi, interfaces.length ? interfaces.slice(0, 2).join(' · ') : 'No active network interface'].filter(Boolean).join(' · ');
  $('#sample-time').textContent = new Date(data.sampled_at * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  $('#api-state').innerHTML = '<i></i> LOCAL CORE';
  $('#api-state').classList.add('connected');
}

async function refreshDiagnostics() {
  try {
    const response = await fetch('/api/diagnostics', { cache: 'no-store' });
    if (!response.ok) throw new Error('Core unavailable');
    updateTelemetry(await response.json());
  } catch {
    $('#api-state').innerHTML = '<i></i> CORE OFFLINE';
    $('#api-state').classList.remove('connected');
  }
}
refreshDiagnostics();
setInterval(refreshDiagnostics, 4500);

let wakeSequence = 0;
let lastAction = 'Core standing by.';
let lastLanguage = 'en';
async function pollState() {
  try {
    const response = await fetch('/api/state', { cache: 'no-store' });
    if (!response.ok) return;
    const data = await response.json();
    if (data.wake_sequence > wakeSequence) {
      wakeSequence = data.wake_sequence;
      triggerIntro(true);
    }
    if (data.last_action && data.last_action !== lastAction && data.last_action !== 'Core standing by.') {
      lastAction = data.last_action;
      lastLanguage = data.last_language || 'en';
      $('#command-response').textContent = lastAction;
      speakReply(lastAction, lastLanguage);
    }
    const listenerAlive = data.listener_status === 'online' && data.listener_seen_at && (Date.now() / 1000 - data.listener_seen_at < 14);
    const listenerLabel = listenerAlive ? 'LISTENER ARMED' : data.listener_status === 'starting' ? 'LISTENER STARTING' : data.listener_error ? 'LISTENER ERROR' : 'LISTENER OFFLINE';
    $('#listener-state').classList.toggle('online', Boolean(listenerAlive));
    $('#listener-state').title = data.listener_error || (listenerAlive ? 'Offline wake-word listener is active.' : 'Waiting for the wake-word listener.');
    $('#listener-state').innerHTML = `<i></i> ${listenerLabel}`;
  } catch { /* The UI reports core status through telemetry polling. */ }
}
pollState();
setInterval(pollState, 1300);

async function sendCommand(text) {
  const responseNode = $('#command-response');
  responseNode.textContent = 'Caraxes is considering the command…';
  responseNode.classList.add('busy');
  try {
    const response = await fetch('/api/command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || 'Command failed.');
    lastAction = result.message;
    lastLanguage = result.language || 'en';
    responseNode.textContent = result.message;
    responseNode.classList.remove('busy');
    speakReply(result.message, lastLanguage);
    if (result.data?.cpu_percent !== undefined) updateTelemetry(result.data);
    if (result.data?.files?.length) {
      const summary = result.data.files.map((path) => `• ${path}`).join('\n');
      responseNode.textContent += `\n${summary}`;
    }
    refreshDiagnostics();
  } catch (error) {
    responseNode.textContent = error.message === 'Failed to fetch' ? 'Local core unavailable. Start the FastAPI service and reload.' : error.message;
    responseNode.classList.remove('busy');
  }
}

$('#command-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const input = $('#command-input');
  const value = input.value.trim();
  if (!value) return;
  sendCommand(value);
  input.value = '';
});
document.querySelectorAll('[data-command]').forEach((button) => button.addEventListener('click', () => sendCommand(button.dataset.command)));
