"""Backward-compatible import path for the packaged wake listener."""

from scripts.wake_listener import capture_one_command, post_json, run, set_listener_status

__all__ = ["capture_one_command", "post_json", "run", "set_listener_status"]


if __name__ == "__main__":
    run()
