"""Compatibility namespace for wake-word listener integrations."""
