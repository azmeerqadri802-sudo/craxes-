"""Native Windows desktop host for the CARAXES local web app."""

from __future__ import annotations

import ctypes
import os
import socket
import sys
import threading
import time
import urllib.error
import urllib.request


def show_error(message: str) -> None:
    try:
        ctypes.windll.user32.MessageBoxW(None, message, "CARAXES could not start", 0x10)
    except Exception:
        pass


def wait_for_api(url: str, server_thread: threading.Thread, timeout: float = 20.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not server_thread.is_alive():
            raise RuntimeError("The local CARAXES service stopped during startup.")
        try:
            with urllib.request.urlopen(url, timeout=0.5) as response:
                if response.status == 200:
                    return
        except (urllib.error.URLError, TimeoutError):
            time.sleep(0.15)
    raise TimeoutError("The local CARAXES service did not become ready.")


def start_wake_listener(port: int) -> threading.Thread:
    """Start the offline listener against this desktop instance's private API."""
    bundle_root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    model_path = bundle_root / "models" / "vosk-model-small-en-us-0.15"
    os.environ["CARAXES_API_BASE"] = f"http://127.0.0.1:{port}"
    os.environ["CARAXES_VOSK_MODEL"] = str(model_path)

    def run_listener() -> None:
        while True:
            try:
                from scripts.wake_listener import run

                if run():
                    return
            except Exception as exc:
                # Keep the dashboard usable if a microphone or Windows privacy
                # setting blocks input, and report the reason through the API.
                try:
                    from backend.main import state_lock, state

                    with state_lock:
                        state["listener_status"] = "offline"
                        state["listener_error"] = f"{type(exc).__name__}: {exc}"[:300]
                except Exception:
                    pass
            time.sleep(15)

    thread = threading.Thread(target=run_listener, name="caraxes-wake-listener", daemon=True)
    thread.start()
    return thread


def main() -> int:
    listener = None
    server = None
    server_thread = None
    try:
        # Reserve an ephemeral loopback port and pass the already-bound socket
        # to Uvicorn so another process cannot claim it between selection/use.
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind(("127.0.0.1", 0))
        listener.listen(socket.SOMAXCONN)
        port = listener.getsockname()[1]
        os.environ["CARAXES_ALLOWED_ORIGIN"] = f"http://127.0.0.1:{port}"

        import uvicorn
        import webview
        from backend.main import app

        server = uvicorn.Server(uvicorn.Config(
            app,
            host="127.0.0.1",
            port=port,
            log_level="error",
            access_log=False,
            log_config=None,
        ))
        server_thread = threading.Thread(
            target=server.run,
            kwargs={"sockets": [listener]},
            name="caraxes-api",
            daemon=True,
        )
        server_thread.start()
        wait_for_api(f"http://127.0.0.1:{port}/api/health", server_thread)
        start_wake_listener(port)

        webview.create_window(
            "CARAXES — The Blood Wyrm",
            f"http://127.0.0.1:{port}/",
            width=1500,
            height=960,
            min_size=(960, 680),
            background_color="#090708",
        )
        webview.start(gui="edgechromium", debug=False)
        return 0
    except Exception as exc:
        show_error(
            f"CARAXES could not open its desktop window.\n\n{exc}\n\n"
            "Windows WebView2 Runtime is required. Install it, then start CARAXES again."
        )
        return 1
    finally:
        if server is not None:
            server.should_exit = True
        if listener is not None:
            try:
                listener.close()
            except OSError:
                pass
        if server_thread is not None:
            server_thread.join(timeout=5)


if __name__ == "__main__":
    raise SystemExit(main())
