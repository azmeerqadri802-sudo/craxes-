"""Native desktop host and optional background service for CARAXES."""

from __future__ import annotations

import argparse
import ctypes
import os
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path


WINDOW_TITLE = "CARAXES — The Blood Wyrm"


def show_error(message: str) -> None:
    try:
        ctypes.windll.user32.MessageBoxW(None, message, "CARAXES could not start", 0x10)
    except Exception:
        pass


def wait_for_api(url: str, server_thread: threading.Thread | None = None, timeout: float = 20.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if server_thread is not None and not server_thread.is_alive():
            raise RuntimeError("The local CARAXES service stopped during startup.")
        try:
            with urllib.request.urlopen(url, timeout=0.5) as response:
                if response.status == 200:
                    return
        except (urllib.error.URLError, TimeoutError, OSError):
            time.sleep(0.15)
    raise TimeoutError("The local CARAXES service did not become ready.")


def start_wake_listener(port: int) -> threading.Thread:
    """Start the offline listener against this desktop instance's loopback API."""
    bundle_root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    configured_model = os.environ.get("CARAXES_VOSK_MODEL")
    model_path = Path(configured_model).expanduser() if configured_model else bundle_root / "models" / "vosk-model-small-en-us-0.15"
    os.environ["CARAXES_API_BASE"] = f"http://127.0.0.1:{port}"
    os.environ["CARAXES_PORT"] = str(port)
    os.environ["CARAXES_VOSK_MODEL"] = str(model_path)

    def run_listener() -> None:
        while True:
            try:
                from scripts.wake_listener import run

                if run():
                    return
            except Exception as exc:
                try:
                    from backend.main import state_lock, state

                    with state_lock:
                        state["listener_status"] = "offline"
                        state["listener_error"] = f"{type(exc).__name__}: {exc}"[:300]
                except Exception:
                    pass
            time.sleep(15)

    thread = threading.Thread(target=run_listener, name="caraxes-wake-listener", daemon=True)
    thread.start()
    return thread


def _raise_window(*_args) -> None:
    if os.name != "nt":
        return
    user32 = ctypes.windll.user32
    found: list[int] = []
    callback_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def callback(hwnd, _lparam):
        length = user32.GetWindowTextLengthW(hwnd)
        if length:
            title = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, title, length + 1)
            if "caraxes" in title.value.casefold() and user32.IsWindowVisible(hwnd):
                found.append(int(hwnd))
        return True

    user32.EnumWindows(callback_type(callback), 0)
    if found:
        user32.ShowWindow(found[0], 9)
        user32.SetForegroundWindow(found[0])


def show_window(port: int) -> int:
    import webview

    window = webview.create_window(
        WINDOW_TITLE,
        f"http://127.0.0.1:{port}/",
        width=1500,
        height=960,
        min_size=(960, 680),
        background_color="#090708",
    )
    try:
        window.events.shown += _raise_window
    except (AttributeError, TypeError):
        pass
    webview.start(gui="edgechromium" if os.name == "nt" else None, debug=False)
    return 0


def run_service_with_ui(port: int, background: bool) -> int:
    listener = None
    server = None
    server_thread = None
    try:
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind(("127.0.0.1", port))
        listener.listen(socket.SOMAXCONN)
        os.environ["CARAXES_PORT"] = str(port)
        os.environ["CARAXES_ALLOWED_ORIGIN"] = f"http://127.0.0.1:{port}"

        import uvicorn
        from backend.main import app

        server = uvicorn.Server(uvicorn.Config(
            app,
            host="127.0.0.1",
            port=port,
            log_level="error",
            access_log=False,
            log_config=None,
        ))
        server_thread = threading.Thread(
            target=server.run,
            kwargs={"sockets": [listener]},
            name="caraxes-api",
            daemon=True,
        )
        server_thread.start()
        wait_for_api(f"http://127.0.0.1:{port}/api/health", server_thread)
        start_wake_listener(port)
        if background:
            while server_thread.is_alive():
                server_thread.join(timeout=1)
            return 0
        return show_window(port)
    finally:
        if server is not None:
            server.should_exit = True
        if listener is not None:
            try:
                listener.close()
            except OSError:
                pass
        if server_thread is not None:
            server_thread.join(timeout=5)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--background", action="store_true", help="Run API and wake listener silently without opening the dashboard.")
    mode.add_argument("--ui-only", action="store_true", help="Open a dashboard window that connects to the existing API.")
    mode.add_argument("--enable-autostart", action="store_true", help="Start CARAXES in the background when this Windows user signs in.")
    mode.add_argument("--disable-autostart", action="store_true", help="Remove the CARAXES current-user startup registration.")
    parser.add_argument("--port", type=int, default=int(os.environ.get("CARAXES_PORT", "8765")))
    args = parser.parse_args()
    if args.enable_autostart or args.disable_autostart:
        try:
            from scripts.enable_autostart import set_autostart

            set_autostart(args.enable_autostart, args.port)
            return 0
        except Exception as exc:
            show_error(f"CARAXES auto-start could not be updated.\n\n{exc}")
            return 1
    if not 1024 <= args.port <= 65535:
        parser.error("--port must be between 1024 and 65535.")
    os.environ["CARAXES_PORT"] = str(args.port)
    try:
        if args.ui_only:
            wait_for_api(f"http://127.0.0.1:{args.port}/api/health")
            return show_window(args.port)
        try:
            return run_service_with_ui(args.port, args.background)
        except OSError as exc:
            if "address already in use" not in str(exc).casefold() and getattr(exc, "winerror", None) != 10048:
                raise
            wait_for_api(f"http://127.0.0.1:{args.port}/api/health", timeout=3)
            if args.background:
                return 0
            from backend.modules.balerion_automation import focus_caraxes_window

            focus_caraxes_window()
            return 0
    except Exception as exc:
        if not args.background:
            show_error(
                f"CARAXES could not open its desktop window.\n\n{exc}\n\n"
                "Windows WebView2 Runtime is required. Install it, then start CARAXES again."
            )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
