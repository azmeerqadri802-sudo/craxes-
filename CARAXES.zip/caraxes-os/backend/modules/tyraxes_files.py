"""Tyraxes file operations limited to configured, user-owned roots."""

from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from send2trash import send2trash

from backend.modules.common import allowed_roots, resolve_user_path

router = APIRouter(prefix="/tyraxes", tags=["Tyraxes · Files"])


class CreateRequest(BaseModel):
    path: str = Field(min_length=1, max_length=2048)
    kind: str = Field(default="file", pattern="^(file|folder)$")
    contents: str = Field(default="", max_length=1_000_000)


class RenameRequest(BaseModel):
    path: str = Field(min_length=1, max_length=2048)
    new_name: str = Field(min_length=1, max_length=255)


class DeleteRequest(BaseModel):
    path: str = Field(min_length=1, max_length=2048)
    confirmed: bool = False


@router.get("/roots")
def list_roots():
    return {"roots": [str(root) for root in allowed_roots()]}


@router.post("/files/create")
def create_file_or_folder(body: CreateRequest):
    target = resolve_user_path(body.path)
    if target.exists():
        raise HTTPException(status_code=409, detail="The destination already exists.")
    if not target.parent.is_dir():
        raise HTTPException(status_code=404, detail="The destination folder does not exist.")
    try:
        if body.kind == "folder":
            target.mkdir()
        else:
            target.write_text(body.contents, encoding="utf-8", newline="")
    except OSError as exc:
        raise HTTPException(status_code=400, detail=f"Could not create the item: {exc}") from exc
    return {"ok": True, "path": str(target), "kind": body.kind}


@router.post("/files/rename")
def rename_file_or_folder(body: RenameRequest):
    if body.new_name in {".", ".."} or any(separator in body.new_name for separator in ("/", "\\", ":")):
        raise HTTPException(status_code=400, detail="Enter a new name only; paths and drive names are not allowed.")
    source = resolve_user_path(body.path, must_exist=True)
    if source.is_symlink():
        raise HTTPException(status_code=400, detail="Renaming symbolic links is not supported.")
    target = resolve_user_path(str(source.with_name(body.new_name)))
    if target.exists():
        raise HTTPException(status_code=409, detail="An item with that name already exists.")
    try:
        source.rename(target)
    except OSError as exc:
        raise HTTPException(status_code=400, detail=f"Could not rename the item: {exc}") from exc
    return {"ok": True, "old_path": str(source), "path": str(target)}


@router.post("/files/delete")
def delete_file_or_folder(body: DeleteRequest):
    if not body.confirmed:
        raise HTTPException(status_code=409, detail="Confirm the exact item before moving it to the Recycle Bin.")
    target = resolve_user_path(body.path, must_exist=True)
    if target.is_symlink():
        raise HTTPException(status_code=400, detail="Deleting symbolic links is not supported.")
    try:
        send2trash(str(target))
    except OSError as exc:
        raise HTTPException(status_code=400, detail=f"Could not move the item to the Recycle Bin: {exc}") from exc
    return {"ok": True, "path": str(target), "deleted": "recycle-bin"}
