"""CARAXES dragon modules and compatibility routers."""
