"""Meleys diagnostics, also exposed at the legacy /meleys/diagnostics path."""

from __future__ import annotations

import platform
import subprocess
import time
from typing import Any

import psutil
from fastapi import APIRouter

router = APIRouter(prefix="/meleys", tags=["Meleys · Diagnostics"])


def collect_diagnostics() -> dict[str, Any]:
    battery = None
    try:
        item = psutil.sensors_battery()
        if item is not None:
            battery = {"percent": round(item.percent), "plugged": item.power_plugged}
    except (AttributeError, OSError):
        pass

    net = psutil.net_if_stats()
    active = [name for name, info in net.items() if info.isup and name.lower() not in {"lo", "loopback"}]
    wifi_names = [name for name in active if any(token in name.casefold() for token in ("wi-fi", "wifi", "wireless", "wlan"))]
    wifi: dict[str, Any] = {"connected": bool(wifi_names), "interfaces": wifi_names, "available": bool(wifi_names)}
    if platform.system() == "Windows" and not wifi_names:
        try:
            result = subprocess.run(
                ["netsh", "wlan", "show", "interfaces"],
                capture_output=True,
                text=True,
                timeout=3,
                check=False,
                shell=False,
            )
            output = result.stdout.casefold()
            wifi["available"] = result.returncode == 0 and "there is no wireless interface" not in output
            wifi["connected"] = "state                   : connected" in output or "state : connected" in output
        except (OSError, subprocess.TimeoutExpired):
            wifi["available"] = False

    memory = psutil.virtual_memory()
    counters = psutil.net_io_counters()
    return {
        "platform": platform.system(),
        "cpu_percent": psutil.cpu_percent(interval=0.15),
        "memory_percent": memory.percent,
        "memory_used_gb": round(memory.used / (1024**3), 1),
        "memory_total_gb": round(memory.total / (1024**3), 1),
        "battery": battery,
        "wifi": wifi,
        "network": {
            "connected_interfaces": active,
            "bytes_sent": counters.bytes_sent,
            "bytes_received": counters.bytes_recv,
        },
        "sampled_at": time.time(),
    }


@router.get("/diagnostics")
def diagnostics():
    return collect_diagnostics()
