"""Tessarion creative workflows: silence analysis, Adobe job manifests, and JSX hooks."""

from __future__ import annotations

import base64
import binascii
import json
import math
import os
import re
import shutil
import subprocess
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from backend.modules.common import caraxes_data_dir, resolve_user_path

router = APIRouter(prefix="/tessarion", tags=["Tessarion · Adobe Creative Cloud"])
MODULE_DIR = Path(__file__).resolve().parent
HOOK_DIR = MODULE_DIR / "adobe_hooks"
UXP_PLUGIN_DIR = MODULE_DIR / "adobe_uxp" / "tessarion_premiere"
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff", ".psd", ".ai"}
MEDIA_SUFFIXES = {".mp4", ".mov", ".mxf", ".wav", ".mp3", ".m4a", ".aac", ".flac", ".avi", ".mkv"}


class SilenceAnalysisRequest(BaseModel):
    media_path: str = Field(min_length=1, max_length=2048)
    threshold_db: float = Field(default=-42, ge=-80, le=-10)
    min_silence_seconds: float = Field(default=0.45, ge=0.15, le=30)


class SilenceRange(BaseModel):
    start: float = Field(ge=0)
    end: float = Field(gt=0)


class PremiereEditRequest(BaseModel):
    source_path: str | None = Field(default=None, max_length=2048)
    silences: list[SilenceRange] = Field(default_factory=list, max_length=600)
    sfx_path: str | None = Field(default=None, max_length=2048)
    transition_seconds: float = Field(default=0, ge=0, le=2)


class SilenceCutRenderRequest(BaseModel):
    media_path: str = Field(min_length=1, max_length=2048)
    silences: list[SilenceRange] = Field(default_factory=list, max_length=600)
    sfx_path: str | None = Field(default=None, max_length=2048)
    transition_seconds: float = Field(default=0, ge=0, le=2)


class BrollAsset(BaseModel):
    path: str = Field(min_length=1, max_length=2048)
    at_seconds: float = Field(ge=0)
    prompt: str = Field(default="", max_length=2000)


class BrollPlanRequest(BaseModel):
    shots: list[str] = Field(min_length=1, max_length=30)
    assets: list[BrollAsset] = Field(default_factory=list, max_length=60)


class BrollGenerationRequest(BaseModel):
    prompts: list[str] = Field(min_length=1, max_length=4)
    at_seconds: list[float] = Field(default_factory=list, max_length=4)


class MotionGraphicsRequest(BaseModel):
    text: str = Field(min_length=1, max_length=500)
    comp_name: str = Field(default="CARAXES Motion Title", min_length=1, max_length=120)
    duration_seconds: float = Field(default=5, ge=1, le=120)
    fps: float = Field(default=30, ge=1, le=120)
    output_path: str | None = Field(default=None, max_length=2048)
    render: bool = False


class AssetHookRequest(BaseModel):
    asset_path: str = Field(min_length=1, max_length=2048)


def _require_media(path_text: str, suffixes: set[str]) -> Path:
    path = resolve_user_path(path_text, must_exist=True)
    if not path.is_file() or path.suffix.casefold() not in suffixes:
        raise HTTPException(status_code=400, detail="The selected item is not a supported media file.")
    return path


def _write_job(name: str, payload: dict[str, Any]) -> Path:
    path = caraxes_data_dir("AdobeJobs") / name
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def _jsx_string(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def _render_hook(template_name: str, replacements: dict[str, str]) -> str:
    try:
        source = (HOOK_DIR / template_name).read_text(encoding="utf-8")
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Adobe hook is missing: {template_name}") from exc
    for key, value in replacements.items():
        source = source.replace(f"__{key}__", value)
    if re.search(r"__[A-Z_]+__", source):
        raise HTTPException(status_code=500, detail="An Adobe script parameter was not filled.")
    return source


def _generate_image(prompt: str) -> bytes:
    """Call a configured OpenAI-compatible image endpoint; never send images without opt-in config."""
    endpoint = os.environ.get("CARAXES_IMAGEGEN_URL", "").strip()
    if not endpoint:
        raise HTTPException(status_code=503, detail="Set CARAXES_IMAGEGEN_URL to enable image generation.")
    parsed = urllib.parse.urlsplit(endpoint)
    host = (parsed.hostname or "").casefold()
    is_loopback = host in {"localhost", "127.0.0.1", "::1"}
    if (parsed.scheme != "https" and not (parsed.scheme == "http" and is_loopback)) or not parsed.hostname:
        raise HTTPException(status_code=500, detail="The image provider must use HTTPS or a loopback HTTP address.")
    model = os.environ.get("CARAXES_IMAGEGEN_MODEL", "gpt-image-1")
    payload = json.dumps({"model": model, "prompt": prompt, "size": "1536x1024", "n": 1}).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    api_key = os.environ.get("CARAXES_IMAGEGEN_API_KEY")
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    request = urllib.request.Request(endpoint, data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=240) as response:
            result = json.loads(response.read(20 * 1024 * 1024))
    except urllib.error.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Image provider returned HTTP {exc.code}.") from exc
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=502, detail="Image provider could not complete a valid response.") from exc
    try:
        encoded = result["data"][0]["b64_json"]
        image = base64.b64decode(encoded, validate=True)
    except (KeyError, IndexError, TypeError, ValueError, binascii.Error) as exc:
        raise HTTPException(status_code=502, detail="Image provider must return a base64-encoded image in data[0].b64_json.") from exc
    if not image.startswith(b"\x89PNG\r\n\x1a\n") or len(image) > 20 * 1024 * 1024:
        raise HTTPException(status_code=502, detail="Image provider must return a PNG under 20 MB.")
    return image


@router.get("/status")
def tessarion_status():
    return {
        "dragon": "Tessarion",
        "role": "Adobe Creative Cloud automation",
        "ffmpeg_available": shutil.which("ffmpeg") is not None,
        "supported_apps": ["Premiere Pro UXP 25.6+", "After Effects ExtendScript", "Photoshop ExtendScript", "Illustrator ExtendScript"],
        "premiere_plugin_source": str(UXP_PLUGIN_DIR),
        "job_directory": str(caraxes_data_dir("AdobeJobs")),
        "image_generation": "configured OpenAI-compatible image endpoint" if os.environ.get("CARAXES_IMAGEGEN_URL") else "not configured",
    }


@router.post("/premiere/analyze-silence")
def analyze_silence(body: SilenceAnalysisRequest):
    media = _require_media(body.media_path, MEDIA_SUFFIXES)
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise HTTPException(status_code=503, detail="FFmpeg is not installed or not available on PATH.")
    sink = "NUL" if os.name == "nt" else os.devnull
    command = [
        ffmpeg, "-hide_banner", "-nostats", "-i", str(media),
        "-af", f"silencedetect=noise={body.threshold_db}dB:d={body.min_silence_seconds}",
        "-f", "null", sink,
    ]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=1800, check=False, shell=False)
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(status_code=504, detail="Silence analysis exceeded the 30 minute limit.") from exc
    except OSError as exc:
        raise HTTPException(status_code=503, detail=f"FFmpeg could not start: {exc}") from exc
    output = result.stderr or ""
    starts = re.finditer(r"silence_start:\s*([0-9]+(?:\.[0-9]+)?)", output)
    start_values = [float(match.group(1)) for match in starts]
    ends = list(re.finditer(r"silence_end:\s*([0-9]+(?:\.[0-9]+)?)\s*\|\s*silence_duration:\s*([0-9]+(?:\.[0-9]+)?)", output))
    ranges = [{"start": start_values[index], "end": float(match.group(1)), "duration": float(match.group(2))}
              for index, match in enumerate(ends) if index < len(start_values)]
    if result.returncode != 0 and not ranges:
        tail = output[-700:].strip()
        raise HTTPException(status_code=422, detail=f"FFmpeg could not analyze this file. {tail}")
    duration, _has_video, _has_audio = _probe_media(media)
    trailing = re.search(r"silence_start:\s*([0-9]+(?:\.[0-9]+)?)\s*$", output)
    if trailing and (not ranges or float(trailing.group(1)) > ranges[-1]["end"]):
        start = float(trailing.group(1))
        if start < duration:
            ranges.append({"start": start, "end": duration, "duration": duration - start})
    payload = {
        "kind": "caraxes.premiere.silence-analysis.v1",
        "source_path": str(media),
        "threshold_db": body.threshold_db,
        "min_silence_seconds": body.min_silence_seconds,
        "silences": ranges,
    }
    job_path = _write_job(f"silence-analysis-{media.stem}.json", payload)
    return {"silence_count": len(ranges), "silences": ranges, "job_path": str(job_path), "source_path": str(media)}


@router.post("/premiere/prepare-edit")
def prepare_premiere_edit(body: PremiereEditRequest):
    silences = sorted((item.model_dump() for item in body.silences), key=lambda item: item["start"])
    for current, following in zip(silences, silences[1:]):
        if current["end"] <= current["start"] or current["end"] > following["start"]:
            raise HTTPException(status_code=400, detail="Silence ranges must be positive and non-overlapping.")
    if silences and silences[-1]["end"] <= silences[-1]["start"]:
        raise HTTPException(status_code=400, detail="Silence ranges must have a positive duration.")
    source = _require_media(body.source_path, MEDIA_SUFFIXES) if body.source_path else None
    sfx = _require_media(body.sfx_path, MEDIA_SUFFIXES) if body.sfx_path else None
    cut_points = sorted({round(point, 6) for item in silences for point in (item["start"], item["end"])})
    payload = {
        "kind": "caraxes.premiere.edit-plan.v1",
        "source_path": str(source) if source else None,
        "silences": silences,
        "cut_points": cut_points,
        "sfx_path": str(sfx) if sfx else None,
        "transition_seconds": body.transition_seconds,
        "undo_label": "CARAXES Tessarion silence edit",
    }
    path = _write_job("premiere-edit-plan.json", payload)
    return {"ok": True, "job_path": str(path), "silence_count": len(silences), "cut_points": cut_points,
            "review": "Load this plan in the Tessarion Premiere UXP panel. Timeline edits are grouped in one Premiere undo transaction."}


def _probe_media(path: Path) -> tuple[float, bool, bool]:
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        raise HTTPException(status_code=503, detail="FFprobe is not installed or not available on PATH.")
    try:
        result = subprocess.run(
            [ffprobe, "-v", "error", "-show_entries", "format=duration:stream=codec_type", "-of", "json", str(path)],
            capture_output=True, text=True, timeout=30, check=False, shell=False,
        )
        info = json.loads(result.stdout or "{}")
        duration = float(info.get("format", {}).get("duration", 0))
        streams = {stream.get("codec_type") for stream in info.get("streams", [])}
    except (OSError, subprocess.TimeoutExpired, ValueError, TypeError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=422, detail="FFprobe could not read the selected media file.") from exc
    if result.returncode != 0 or not math.isfinite(duration) or duration <= 0:
        raise HTTPException(status_code=422, detail="Selected media has no usable duration.")
    has_video, has_audio = "video" in streams, "audio" in streams
    if not has_video and not has_audio:
        raise HTTPException(status_code=422, detail="Selected media has no audio or video stream.")
    return duration, has_video, has_audio


@router.post("/premiere/render-silence-cut")
def render_silence_cut(body: SilenceCutRenderRequest):
    """Render a new silence-trimmed media file; the original file stays untouched."""
    media = _require_media(body.media_path, MEDIA_SUFFIXES)
    sfx = _require_media(body.sfx_path, MEDIA_SUFFIXES) if body.sfx_path else None
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise HTTPException(status_code=503, detail="FFmpeg is not installed or not available on PATH.")
    if len(body.silences) > 120:
        raise HTTPException(status_code=400, detail="One render can remove at most 120 silence ranges.")
    duration, has_video, has_audio = _probe_media(media)
    silences = sorted((item.model_dump() for item in body.silences), key=lambda item: item["start"])
    previous_end = 0.0
    for item in silences:
        start, end = float(item["start"]), float(item["end"])
        if not math.isfinite(start) or not math.isfinite(end) or end <= start or start < previous_end or end > duration:
            raise HTTPException(status_code=400, detail="Silence ranges must be finite, ordered, non-overlapping, and within the media duration.")
        previous_end = end
    keep_ranges: list[tuple[float, float]] = []
    cursor = 0.0
    for item in silences:
        start = float(item["start"])
        end = float(item["end"])
        if start - cursor >= 0.04:
            keep_ranges.append((cursor, start))
        cursor = end
    if duration - cursor >= 0.04:
        keep_ranges.append((cursor, duration))
    if not keep_ranges:
        raise HTTPException(status_code=400, detail="The silence plan would remove the entire media file.")

    filters: list[str] = []
    concat_inputs: list[str] = []
    for index, (start, end) in enumerate(keep_ranges):
        if has_video:
            filters.append(f"[0:v:0]trim=start={start:.6f}:end={end:.6f},setpts=PTS-STARTPTS[v{index}]")
            concat_inputs.append(f"[v{index}]")
        if has_audio:
            filters.append(f"[0:a:0]atrim=start={start:.6f}:end={end:.6f},asetpts=PTS-STARTPTS[a{index}]")
            concat_inputs.append(f"[a{index}]")
    if has_video and has_audio:
        concat_inputs = [label for index in range(len(keep_ranges)) for label in (f"[v{index}]", f"[a{index}]")]
        filters.append("".join(concat_inputs) + f"concat=n={len(keep_ranges)}:v=1:a=1[outv][outa]")
    elif has_video:
        filters.append("".join(concat_inputs) + f"concat=n={len(keep_ranges)}:v=1:a=0[outv]")
    else:
        filters.append("".join(concat_inputs) + f"concat=n={len(keep_ranges)}:v=0:a=1[outa]")

    output_dir = caraxes_data_dir("RenderedEdits")
    suffix = ".mp4" if has_video else ".m4a"
    output = output_dir / f"{media.stem}-tessarion-{uuid.uuid4().hex}{suffix}"
    command = [ffmpeg, "-hide_banner", "-n", "-i", str(media), "-filter_complex", ";".join(filters)]
    if has_video:
        command.extend(["-map", "[outv]", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p"])
    if has_audio:
        command.extend(["-map", "[outa]", "-c:a", "aac", "-b:a", "192k"])
    command.extend([str(output)])
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=7200, check=False, shell=False)
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(status_code=504, detail="Silence-cut render exceeded the two hour limit.") from exc
    except OSError as exc:
        raise HTTPException(status_code=503, detail=f"FFmpeg could not start: {exc}") from exc
    if result.returncode != 0 or not output.is_file():
        output.unlink(missing_ok=True)
        raise HTTPException(status_code=422, detail=f"FFmpeg could not render the silence cut. {(result.stderr or '')[-700:]}")

    # The rendered file has compacted time. Place SFX and transitions at the
    # boundaries between kept segments, rather than at their old source times.
    compact_time = 0.0
    cut_points: list[float] = []
    for segment_start, segment_end in keep_ranges[:-1]:
        compact_time += segment_end - segment_start
        cut_points.append(round(compact_time, 6))
    payload = {
        "kind": "caraxes.premiere.broll-plan.v1",
        "source_path": str(media),
        "silences": [],
        "cut_points": cut_points,
        "assets": [{"path": str(output), "at_seconds": 0, "kind": "edited-video"}],
        "sfx_path": str(sfx) if sfx else None,
        "transition_seconds": body.transition_seconds,
        "undo_label": "CARAXES Tessarion silence-cut insert",
    }
    job_path = _write_job(f"silence-cut-{output.stem}.json", payload)
    return {
        "ok": True,
        "source_path": str(media),
        "rendered_path": str(output),
        "job_path": str(job_path),
        "removed_silence_seconds": round(sum(item["end"] - item["start"] for item in silences), 3),
        "kept_segments": len(keep_ranges),
        "instruction": "Load the job in Premiere's Tessarion UXP panel to insert the rendered edit. The original source file is unchanged.",
    }


@router.post("/premiere/prepare-broll")
def prepare_broll(body: BrollPlanRequest):
    assets: list[dict[str, Any]] = []
    for asset in body.assets:
        path = _require_media(asset.path, IMAGE_SUFFIXES)
        assets.append({"path": str(path), "at_seconds": asset.at_seconds, "prompt": asset.prompt})
    prompts = [f"Cinematic B-roll still, 16:9, no text or logos. Scene: {shot.strip()}" for shot in body.shots]
    payload = {"kind": "caraxes.premiere.broll-plan.v1", "prompts": prompts, "assets": assets,
               "note": "Generate images with your chosen provider, then supply their local file paths in assets."}
    path = _write_job("premiere-broll-plan.json", payload)
    return {"job_path": str(path), "prompts": prompts, "assets_ready": len(assets), "assets_needed": max(0, len(prompts) - len(assets))}


@router.post("/broll/generate")
def generate_broll(body: BrollGenerationRequest):
    if body.at_seconds and len(body.at_seconds) != len(body.prompts):
        raise HTTPException(status_code=400, detail="Provide one timeline time for each image prompt, or omit at_seconds.")
    if any(not math.isfinite(value) or value < 0 for value in body.at_seconds):
        raise HTTPException(status_code=400, detail="B-roll timeline times must be finite and non-negative.")
    assets: list[dict[str, Any]] = []
    output_dir = caraxes_data_dir("GeneratedBroll")
    try:
        for index, raw_prompt in enumerate(body.prompts):
            prompt = raw_prompt.strip()
            if not prompt:
                raise HTTPException(status_code=400, detail="Every image prompt must contain text.")
            full_prompt = f"Cinematic B-roll still, 16:9 composition, no text or logos. Scene: {prompt}"
            image = _generate_image(full_prompt)
            image_path = output_dir / f"tessarion-{uuid.uuid4().hex}.png"
            image_path.write_bytes(image)
            assets.append({"path": str(image_path), "at_seconds": body.at_seconds[index] if body.at_seconds else index * 5.0,
                           "kind": "broll", "prompt": prompt})
    except Exception:
        for asset in assets:
            Path(asset["path"]).unlink(missing_ok=True)
        raise
    job_path = _write_job(f"premiere-generated-broll-{uuid.uuid4().hex[:8]}.json", {
        "kind": "caraxes.premiere.broll-plan.v1", "prompts": body.prompts, "assets": assets,
        "transition_seconds": 0, "undo_label": "CARAXES Tessarion generated B-roll",
    })
    return {"ok": True, "assets": assets, "job_path": str(job_path),
            "photoshop_script_endpoint": "/tessarion/photoshop/import-asset",
            "illustrator_script_endpoint": "/tessarion/illustrator/place-asset"}


@router.post("/after-effects/motion-graphics")
def prepare_motion_graphics(body: MotionGraphicsRequest):
    output_path = "null"
    if body.output_path:
        output = resolve_user_path(body.output_path)
        if output.suffix.casefold() not in {".mov", ".mp4", ".avi", ".mxf"}:
            raise HTTPException(status_code=400, detail="Render output must use .mov, .mp4, .avi, or .mxf.")
        if output.exists():
            raise HTTPException(status_code=409, detail="The render output already exists; choose a new path.")
        if not output.parent.is_dir():
            raise HTTPException(status_code=404, detail="The render output folder does not exist.")
        output_path = str(output)
    if body.render and output_path == "null":
        raise HTTPException(status_code=400, detail="Provide a new output_path when render=true.")
    script = _render_hook("after_effects_motion_graphics.jsx", {
        "TITLE": _jsx_string(body.text),
        "COMP_NAME": _jsx_string(body.comp_name),
        "DURATION": str(body.duration_seconds),
        "FPS": str(body.fps),
        "RENDER": "true" if body.render else "false",
        "OUTPUT_PATH": _jsx_string(output_path),
    })
    file_path = caraxes_data_dir("AdobeScripts") / "Tessarion-Motion-Graphics.jsx"
    file_path.write_text(script, encoding="utf-8-sig")
    return {"ok": True, "script_path": str(file_path), "render": body.render,
            "instruction": "Open this JSX from After Effects: File > Scripts > Run Script File. Review the composition before rendering."}


@router.post("/photoshop/import-asset")
def prepare_photoshop_import(body: AssetHookRequest):
    asset = _require_media(body.asset_path, IMAGE_SUFFIXES)
    script = _render_hook("photoshop_import_asset.jsx", {"ASSET_PATH": _jsx_string(str(asset))})
    file_path = caraxes_data_dir("AdobeScripts") / "Tessarion-Photoshop-Import.jsx"
    file_path.write_text(script, encoding="utf-8-sig")
    return {"ok": True, "script_path": str(file_path), "instruction": "Open the destination Photoshop document, then run this JSX script."}


@router.post("/illustrator/place-asset")
def prepare_illustrator_place(body: AssetHookRequest):
    asset = _require_media(body.asset_path, IMAGE_SUFFIXES)
    script = _render_hook("illustrator_place_asset.jsx", {"ASSET_PATH": _jsx_string(str(asset))})
    file_path = caraxes_data_dir("AdobeScripts") / "Tessarion-Illustrator-Place.jsx"
    file_path.write_text(script, encoding="utf-8-sig")
    return {"ok": True, "script_path": str(file_path), "instruction": "Open an Illustrator document, then run this JSX script to place the asset."}


@router.post("/premiere/install-uxp-source")
def install_premiere_uxp_source():
    if not UXP_PLUGIN_DIR.is_dir():
        raise HTTPException(status_code=500, detail="The bundled Tessarion Premiere UXP source is missing.")
    target = caraxes_data_dir("AdobePlugins", "TessarionPremiere")
    shutil.copytree(UXP_PLUGIN_DIR, target, dirs_exist_ok=True)
    return {"ok": True, "plugin_path": str(target),
            "instruction": "Load manifest.json in Adobe UXP Developer Tool while Premiere Pro 25.6+ is open. Enable Premiere Developer Mode first."}
