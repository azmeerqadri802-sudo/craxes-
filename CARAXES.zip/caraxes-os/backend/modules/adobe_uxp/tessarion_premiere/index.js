const premiere = require("premierepro");
const { entrypoints } = require("uxp");
const { localFileSystem } = require("uxp").storage;

let job = null;

function tick(seconds) {
  return premiere.TickTime.createWithSeconds(Number(seconds));
}

function status(text) {
  const node = document.getElementById("status");
  if (node) node.textContent = text;
}

function setButtons(enabled) {
  document.getElementById("silence").disabled = !enabled;
  document.getElementById("assets").disabled = !enabled;
}

async function loadJob() {
  const file = await localFileSystem.getFileForOpening({ types: ["json"] });
  if (!file) return;
  const candidate = JSON.parse(await file.read());
  if (!candidate || !String(candidate.kind || "").startsWith("caraxes.premiere.")) {
    throw new Error("This is not a CARAXES Premiere job manifest.");
  }
  job = candidate;
  setButtons(true);
  status(`Loaded: ${job.kind}\nSilences: ${(job.silences || []).length}\nB-roll assets: ${(job.assets || []).length}\nSFX: ${job.sfx_path || "none"}`);
}

function commitActions(project, actions, undoName) {
  if (!actions.length) return false;
  return project.executeTransaction((compound) => {
    for (const action of actions) compound.addAction(action);
  }, undoName);
}

async function applySilenceEdit() {
  if (!job || !Array.isArray(job.silences) || !job.silences.length) throw new Error("Load a silence-analysis or edit-plan manifest first.");
  if (!window.confirm(`Apply ${job.silences.length} silence ranges to the active Premiere sequence? The edit is undoable with Ctrl+Z.`)) return;
  const project = await premiere.Project.getActiveProject();
  const sequence = await project.getActiveSequence();
  if (!project || !sequence) throw new Error("Open a Premiere project and activate a sequence first.");
  const editor = premiere.SequenceEditor.getEditor(sequence);
  const actions = [];
  const quietClips = [];
  const markers = await premiere.Markers.getMarkers(sequence);
  const videoCount = await sequence.getVideoTrackCount();
  const audioCount = await sequence.getAudioTrackCount();
  const trackGroups = [
    { count: videoCount, get: (index) => sequence.getVideoTrack(index) },
    { count: audioCount, get: (index) => sequence.getAudioTrack(index) },
  ];
  let interiorCutMarkers = 0;

  for (const group of trackGroups) {
    for (let index = 0; index < group.count; index += 1) {
      const track = await group.get(index);
      const clips = await track.getTrackItems(premiere.Constants.TrackItemType.CLIP, false);
      for (const clip of clips) {
        const start = (await clip.getStartTime()).seconds;
        const end = (await clip.getEndTime()).seconds;
        for (const range of job.silences) {
          const quietStart = Number(range.start);
          const quietEnd = Number(range.end);
          if (!(start < quietEnd && end > quietStart)) continue;
          if (start >= quietStart && end <= quietEnd) {
            quietClips.push(clip);
          } else if (start < quietStart && end <= quietEnd) {
            actions.push(clip.createSetEndAction(tick(quietStart)));
          } else if (start >= quietStart && start < quietEnd && end > quietEnd) {
            actions.push(clip.createSetStartAction(tick(quietEnd)));
          } else if (start < quietStart && end > quietEnd) {
            actions.push(markers.createAddMarkerAction("Tessarion cut", "Comment", tick(quietStart), tick(0), "Silence starts here; this clip crosses the full quiet range."));
            actions.push(markers.createAddMarkerAction("Tessarion cut", "Comment", tick(quietEnd), tick(0), "Silence ends here; split this continuous clip at both markers."));
            interiorCutMarkers += 2;
          }
        }
      }
    }
  }

  if (quietClips.length) {
    let removeAction = null;
    premiere.TrackItemSelection.createEmptySelection((selection) => {
      for (const clip of quietClips) selection.addItem(clip, true);
      removeAction = editor.createRemoveItemsAction(selection, true, premiere.Constants.MediaType.ANY, true);
    });
    if (removeAction) actions.push(removeAction);
  }
  const committed = commitActions(project, actions, job.undo_label || "CARAXES Tessarion silence edit");
  await project.save();
  status(`Silence edit applied: ${quietClips.length} fully quiet clips removed; ${actions.length} timeline actions committed; ${interiorCutMarkers} interior cut markers need clip splitting.\nUse Premiere undo (Ctrl+Z) to revert.`);
  return committed;
}

async function importProjectItem(project, path) {
  const bin = await project.getRootItem();
  const imported = await project.importFiles([path], true, bin, false);
  if (!imported) throw new Error(`Premiere could not import: ${path}`);
  const candidates = await project.findItemsMatchingMediaPath(path, true);
  for (const item of candidates) {
    if (typeof item.getMediaFilePath !== "function" || (await item.getMediaFilePath()) === path) return item;
  }
  if (candidates.length) return candidates[0];
  throw new Error(`Premiere imported the media but did not return a project item: ${path}`);
}

async function addTransitions(sequence, cutPoints, durationSeconds) {
  if (!(durationSeconds > 0) || !cutPoints.length) return [];
  const names = await premiere.TransitionFactory.getVideoTransitionMatchNames();
  const matchName = names.find((name) => /cross.?dissolve|cross.?fade/i.test(name)) || names.find((name) => /dissolve/i.test(name));
  if (!matchName) return [];
  const transition = premiere.TransitionFactory.createVideoTransition(matchName);
  const options = new premiere.AddTransitionOptions();
  options.setDuration(tick(durationSeconds));
  options.setForceSingleSided(true);
  const trackCount = await sequence.getVideoTrackCount();
  const actions = [];
  for (let trackIndex = 0; trackIndex < trackCount; trackIndex += 1) {
    const track = await sequence.getVideoTrack(trackIndex);
    const clips = await track.getTrackItems(premiere.Constants.TrackItemType.CLIP, false);
    for (const clip of clips) {
      const start = (await clip.getStartTime()).seconds;
      const end = (await clip.getEndTime()).seconds;
      if (cutPoints.some((point) => Math.abs(start - point) < durationSeconds * 0.75)) {
        options.setApplyToStart(true);
        actions.push(clip.createAddVideoTransitionAction(transition, options));
      } else if (cutPoints.some((point) => Math.abs(end - point) < durationSeconds * 0.75)) {
        options.setApplyToStart(false);
        actions.push(clip.createAddVideoTransitionAction(transition, options));
      }
    }
  }
  return actions;
}

async function placeAssets() {
  if (!job) throw new Error("Load a CARAXES Premiere manifest first.");
  const assetList = [...(job.assets || [])];
  const cutPoints = job.cut_points || [];
  if (job.sfx_path) {
    for (const atSeconds of cutPoints) assetList.push({ path: job.sfx_path, at_seconds: atSeconds, kind: "sfx" });
  }
  if (!assetList.length) throw new Error("This manifest contains no local SFX or B-roll assets.");
  if (!window.confirm(`Import and place ${assetList.length} media item(s) into the active sequence?`)) return;
  const project = await premiere.Project.getActiveProject();
  const sequence = await project.getActiveSequence();
  if (!project || !sequence) throw new Error("Open a Premiere project and activate a sequence first.");
  const editor = premiere.SequenceEditor.getEditor(sequence);
  const videoCount = await sequence.getVideoTrackCount();
  const audioCount = await sequence.getAudioTrackCount();
  const actions = [];
  for (const asset of assetList) {
    const item = await importProjectItem(project, asset.path);
    const audioOnly = asset.kind === "sfx" || /\.(wav|mp3|m4a|aac|flac)$/i.test(asset.path);
    actions.push(editor.createInsertProjectItemAction(
      item,
      tick(asset.at_seconds),
      Math.max(0, videoCount - 1),
      Math.max(0, audioCount - 1),
      false,
    ));
    if (audioOnly) status(`Preparing audio insert at ${Number(asset.at_seconds).toFixed(2)}s…`);
  }
  if (job.transition_seconds > 0) actions.push(...await addTransitions(sequence, cutPoints, job.transition_seconds));
  commitActions(project, actions, "CARAXES Tessarion SFX and B-roll placement");
  await project.save();
  status(`Placed ${assetList.length} media item(s).${job.transition_seconds > 0 ? " Transition actions were added where clip edges matched cut points." : ""}`);
}

function bind(rootNode) {
  rootNode.querySelector("#load").addEventListener("click", () => loadJob().catch((error) => status(error.message)));
  rootNode.querySelector("#silence").addEventListener("click", () => applySilenceEdit().catch((error) => status(error.message)));
  rootNode.querySelector("#assets").addEventListener("click", () => placeAssets().catch((error) => status(error.message)));
}

entrypoints.setup({
  panels: {
    tessarionPanel: {
      create(rootNode) {
        bind(rootNode);
      },
    },
  },
});
