"""Balerion native Windows hooks with explicit application and file boundaries."""

from __future__ import annotations

import ctypes
import os
import platform
import shutil
import subprocess
import sys
import time
from ctypes import POINTER, cast
from pathlib import Path
from typing import Literal

import psutil
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from backend.modules.common import allowed_roots
from backend.modules.meleys_diagnostics import collect_diagnostics

router = APIRouter(prefix="/balerion", tags=["Balerion · Automation"])
WINDOWS_BLOCKED_PROCESSES = {"system", "registry", "smss", "csrss", "wininit", "services", "lsass", "svchost", "winlogon", "dwm"}
APP_PROCESS_NAMES = {
    "premiere": {"adobe premiere pro.exe", "premiere pro.exe"},
    "premiere pro": {"adobe premiere pro.exe", "premiere pro.exe"},
    "photoshop": {"photoshop.exe"},
    "after effects": {"afterfx.exe"},
    "illustrator": {"illustrator.exe"},
    "vs code": {"code.exe"},
    "vscode": {"code.exe"},
    "chrome": {"chrome.exe"},
    "calculator": {"calculatorapp.exe", "calc.exe"},
    "notepad": {"notepad.exe"},
}
APP_EXECUTABLES = {
    "premiere": "Adobe Premiere Pro.exe",
    "premiere pro": "Adobe Premiere Pro.exe",
    "photoshop": "Photoshop.exe",
    "after effects": "AfterFX.exe",
    "illustrator": "Illustrator.exe",
    "vs code": "Code.exe",
    "vscode": "Code.exe",
    "chrome": "chrome.exe",
    "calculator": "calc.exe",
    "notepad": "notepad.exe",
}


class AppRequest(BaseModel):
    app: str = Field(min_length=1, max_length=180)
    executable_path: str | None = Field(default=None, max_length=2048)


class ProcessRequest(BaseModel):
    process_name: str = Field(min_length=1, max_length=180)


class CloseAppRequest(ProcessRequest):
    confirmed: bool = False


class VolumeRequest(BaseModel):
    action: Literal["up", "down", "mute", "unmute", "set"]
    level: int | None = Field(default=None, ge=0, le=100)


class BrightnessRequest(BaseModel):
    level: int = Field(ge=0, le=100)


def _trusted_application_roots() -> list[Path]:
    roots = allowed_roots()
    for variable in ("ProgramFiles", "ProgramFiles(x86)", "ProgramW6432", "LOCALAPPDATA"):
        value = os.environ.get(variable)
        if value:
            root = Path(value).resolve()
            if root.is_dir() and root not in roots:
                roots.append(root)
    return roots


def _is_under(path: Path, roots: list[Path]) -> bool:
    return any(path == root or root in path.parents for root in roots)


def _resolve_application(body: AppRequest) -> Path:
    if body.executable_path:
        raw = Path(body.executable_path).expanduser()
        try:
            candidate = raw.resolve(strict=True)
        except OSError as exc:
            raise HTTPException(status_code=404, detail="The application executable was not found.") from exc
        if candidate.suffix.casefold() != ".exe" or not candidate.is_file() or not _is_under(candidate, _trusted_application_roots()):
            raise HTTPException(status_code=403, detail="The executable must be an existing .exe inside a user, Adobe, Program Files, or LocalAppData folder.")
        return candidate

    name = body.app.casefold().strip()
    executable = APP_EXECUTABLES.get(name)
    if executable is None:
        raise HTTPException(status_code=400, detail="For custom apps, provide the installed .exe path inside a trusted app folder.")
    found = shutil.which(executable)
    if found:
        return Path(found).resolve()
    roots = _trusted_application_roots()
    if name in {"premiere", "premiere pro", "photoshop", "after effects", "illustrator"}:
        for root in roots:
            adobe = root / "Adobe"
            if not adobe.is_dir():
                continue
            for app_folder in adobe.iterdir():
                if not app_folder.is_dir():
                    continue
                candidates = list(app_folder.glob(executable)) + list(app_folder.glob(f"**/{executable}"))
                for candidate in candidates[:8]:
                    if candidate.is_file():
                        return candidate.resolve()
    common_candidates = {
        "vs code": [Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Microsoft VS Code" / executable],
        "vscode": [Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Microsoft VS Code" / executable],
        "chrome": [Path(os.environ.get("ProgramFiles", "")) / "Google/Chrome/Application" / executable,
                   Path(os.environ.get("ProgramFiles(x86)", "")) / "Google/Chrome/Application" / executable],
    }
    for candidate in common_candidates.get(name, []):
        if candidate.is_file():
            return candidate.resolve()
    raise HTTPException(status_code=404, detail=f"{body.app} is not installed in a known application folder.")


def _matching_processes(process_name: str):
    requested = Path(process_name.strip().strip('"')).name.casefold()
    if not requested.endswith(".exe"):
        requested += ".exe"
    if requested.removesuffix(".exe") in WINDOWS_BLOCKED_PROCESSES:
        raise HTTPException(status_code=403, detail="This operating-system process is protected.")
    return [proc for proc in psutil.process_iter(["pid", "name"]) if (proc.info.get("name") or "").casefold() == requested]


def _raise_window(hwnd: int) -> None:
    user32 = ctypes.windll.user32
    user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    user32.SetForegroundWindow(hwnd)


def _windows_for_process(pid: int) -> list[int]:
    if platform.system() != "Windows":
        return []
    hwnds: list[int] = []
    user32 = ctypes.windll.user32
    callback_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def callback(hwnd, _lparam):
        process_id = ctypes.c_ulong()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(process_id))
        if process_id.value == pid and user32.IsWindowVisible(hwnd):
            hwnds.append(int(hwnd))
        return True

    user32.EnumWindows(callback_type(callback), 0)
    return hwnds


def _start_ui_only() -> bool:
    global _last_ui_spawn
    if time.monotonic() - _last_ui_spawn < 5:
        return True
    port = int(os.environ.get("CARAXES_PORT", "8765"))
    repo_root = Path(__file__).resolve().parents[2]
    if getattr(sys, "frozen", False):
        argv = [sys.executable, "--ui-only", "--port", str(port)]
    else:
        pythonw = Path(sys.executable).with_name("pythonw.exe")
        executable = str(pythonw if pythonw.is_file() else Path(sys.executable))
        argv = [executable, str(repo_root / "desktop.py"), "--ui-only", "--port", str(port)]
    try:
        subprocess.Popen(argv, cwd=str(repo_root), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, shell=False)
        _last_ui_spawn = time.monotonic()
        return True
    except OSError:
        return False


def focus_caraxes_window() -> bool:
    if platform.system() != "Windows":
        return False
    user32 = ctypes.windll.user32
    match: list[int] = []
    callback_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def callback(hwnd, _lparam):
        length = user32.GetWindowTextLengthW(hwnd)
        if length:
            title = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, title, length + 1)
            if "caraxes" in title.value.casefold() and user32.IsWindowVisible(hwnd):
                match.append(int(hwnd))
        return True

    user32.EnumWindows(callback_type(callback), 0)
    if match:
        _raise_window(match[0])
        return True
    return _start_ui_only()


_last_ui_spawn = 0.0


@router.get("/system")
def system_status():
    return {
        **collect_diagnostics(),
        "brightness_percent": _get_brightness(),
        "volume": _get_volume(),
    }


@router.post("/apps/open")
def open_application(body: AppRequest):
    if platform.system() != "Windows":
        raise HTTPException(status_code=501, detail="Native app launching is currently implemented for Windows.")
    executable = _resolve_application(body)
    try:
        subprocess.Popen([str(executable)], shell=False, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Could not start the application: {exc}") from exc
    return {"ok": True, "app": body.app, "executable": str(executable)}


@router.post("/apps/focus")
def focus_application(body: ProcessRequest):
    if platform.system() != "Windows":
        raise HTTPException(status_code=501, detail="Native application focus is currently implemented for Windows.")
    processes = _matching_processes(body.process_name)
    for proc in processes:
        windows = _windows_for_process(proc.info["pid"])
        if windows:
            _raise_window(windows[0])
            return {"ok": True, "process": proc.info["name"], "focused": True}
    raise HTTPException(status_code=404, detail="No visible window was found for that running application.")


@router.post("/apps/close")
def close_application(body: CloseAppRequest):
    if not body.confirmed:
        raise HTTPException(status_code=409, detail="Confirm closing the named application; it may contain unsaved work.")
    if platform.system() != "Windows":
        raise HTTPException(status_code=501, detail="Native application close is currently implemented for Windows.")
    processes = _matching_processes(body.process_name)
    user32 = ctypes.windll.user32
    count = 0
    for proc in processes:
        for hwnd in _windows_for_process(proc.info["pid"]):
            user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE; let the application show its own save prompt.
            count += 1
    if not count:
        raise HTTPException(status_code=404, detail="No visible application window was found to close.")
    return {"ok": True, "windows_notified": count, "method": "WM_CLOSE"}


@router.post("/desktop/refresh")
def refresh_desktop():
    if platform.system() != "Windows":
        raise HTTPException(status_code=501, detail="Desktop refresh is currently implemented for Windows.")
    ctypes.windll.shell32.SHChangeNotify(0x08000000, 0x0000, None, None)
    return {"ok": True, "action": "shell-change-notification"}


def _volume_interface():
    try:
        from comtypes import CLSCTX_ALL
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

        speakers = AudioUtilities.GetSpeakers()
        interface = speakers.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        return cast(interface, POINTER(IAudioEndpointVolume))
    except (ImportError, OSError, AttributeError):
        return None


def _get_volume():
    interface = _volume_interface()
    if interface is None:
        return {"available": False}
    try:
        return {"available": True, "percent": round(interface.GetMasterVolumeLevelScalar() * 100), "muted": bool(interface.GetMute())}
    except OSError:
        return {"available": False}


@router.post("/volume")
def set_volume(body: VolumeRequest):
    interface = _volume_interface()
    if interface is None:
        raise HTTPException(status_code=503, detail="Windows Core Audio volume control is unavailable.")
    try:
        if body.action == "set":
            if body.level is None:
                raise HTTPException(status_code=400, detail="A 0–100 level is required for set.")
            interface.SetMasterVolumeLevelScalar(body.level / 100, None)
        elif body.action == "up":
            interface.SetMasterVolumeLevelScalar(min(1, interface.GetMasterVolumeLevelScalar() + 0.05), None)
        elif body.action == "down":
            interface.SetMasterVolumeLevelScalar(max(0, interface.GetMasterVolumeLevelScalar() - 0.05), None)
        else:
            interface.SetMute(1 if body.action == "mute" else 0, None)
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Windows volume control failed: {exc}") from exc
    return _get_volume()


def _powershell_output(script: str, *args: str) -> str | None:
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script, *args],
            capture_output=True, text=True, timeout=8, check=False, shell=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    return result.stdout.strip() if result.returncode == 0 else None


def _get_brightness():
    if platform.system() != "Windows":
        return None
    script = "$b=Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightness -ErrorAction Stop; [int]$b.CurrentBrightness"
    value = _powershell_output(script)
    try:
        return int(value) if value else None
    except ValueError:
        return None


@router.post("/brightness")
def set_brightness(body: BrightnessRequest):
    if platform.system() != "Windows":
        raise HTTPException(status_code=501, detail="Monitor brightness control is currently implemented for Windows laptops.")
    script = (
        "param([int]$level); $m=Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightnessMethods -ErrorAction Stop; "
        "Invoke-CimMethod -InputObject $m -MethodName WmiSetBrightness -Arguments @{Timeout=1;Brightness=$level} -ErrorAction Stop | Out-Null"
    )
    result = _powershell_output(script, str(body.level))
    if result is None:
        raise HTTPException(status_code=503, detail="Windows could not set brightness; this display may not expose WMI brightness controls.")
    return {"ok": True, "brightness_percent": body.level}


@router.post("/window/focus")
def focus_caraxes():
    focused = focus_caraxes_window()
    return {"ok": focused, "focused_or_started": focused}
