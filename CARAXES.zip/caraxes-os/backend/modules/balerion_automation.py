"""Balerion native desktop controls and current-user command execution."""

from __future__ import annotations

import ctypes
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from ctypes import POINTER, cast
from pathlib import Path
from typing import Literal

import psutil
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from backend.modules.common import allowed_roots
from backend.modules.meleys_diagnostics import collect_diagnostics

router = APIRouter(prefix="/balerion", tags=["Balerion · Automation"])
WINDOWS_BLOCKED_PROCESSES = {"system", "registry", "smss", "csrss", "wininit", "services", "lsass", "svchost", "winlogon", "dwm"}
APP_PROCESS_NAMES = {
    "premiere": {"adobe premiere pro.exe", "premiere pro.exe"},
    "premiere pro": {"adobe premiere pro.exe", "premiere pro.exe"},
    "photoshop": {"photoshop.exe"},
    "after effects": {"afterfx.exe"},
    "illustrator": {"illustrator.exe"},
    "vs code": {"code.exe"},
    "vscode": {"code.exe"},
    "chrome": {"chrome.exe"},
    "calculator": {"calculatorapp.exe", "calc.exe"},
    "notepad": {"notepad.exe"},
}
APP_EXECUTABLES = {
    "premiere": "Adobe Premiere Pro.exe",
    "premiere pro": "Adobe Premiere Pro.exe",
    "photoshop": "Photoshop.exe",
    "after effects": "AfterFX.exe",
    "illustrator": "Illustrator.exe",
    "vs code": "Code.exe",
    "vscode": "Code.exe",
    "chrome": "chrome.exe",
    "calculator": "calc.exe",
    "notepad": "notepad.exe",
    "edge": "msedge.exe",
    "microsoft edge": "msedge.exe",
    "word": "WINWORD.EXE",
    "excel": "EXCEL.EXE",
    "powerpoint": "POWERPNT.EXE",
    "vlc": "vlc.exe",
}


class AppRequest(BaseModel):
    app: str = Field(min_length=1, max_length=180)
    executable_path: str | None = Field(default=None, max_length=2048)


class ProcessRequest(BaseModel):
    process_name: str = Field(min_length=1, max_length=180)


class CloseAppRequest(ProcessRequest):
    confirmed: bool = False


class VolumeRequest(BaseModel):
    action: Literal["up", "down", "mute", "unmute", "set"]
    level: int | None = Field(default=None, ge=0, le=100)


class BrightnessRequest(BaseModel):
    level: int = Field(ge=0, le=100)


class BrightnessChangeRequest(BaseModel):
    direction: Literal["up", "down"]


class TerminalRequest(BaseModel):
    command: str = Field(min_length=1, max_length=3000)


class KeypressRequest(BaseModel):
    keys: str = Field(min_length=1, max_length=120)


class TypeTextRequest(BaseModel):
    text: str = Field(min_length=1, max_length=2000)


class ClickRequest(BaseModel):
    x: int = Field(ge=0, le=32767)
    y: int = Field(ge=0, le=32767)
    button: Literal["left", "right", "middle"] = "left"
    clicks: int = Field(default=1, ge=1, le=2)


def _trusted_application_roots() -> list[Path]:
    roots = allowed_roots()
    for variable in ("ProgramFiles", "ProgramFiles(x86)", "ProgramW6432", "LOCALAPPDATA"):
        value = os.environ.get(variable)
        if value:
            root = Path(value).resolve()
            if root.is_dir() and root not in roots:
                roots.append(root)
    return roots


def _is_under(path: Path, roots: list[Path]) -> bool:
    return any(path == root or root in path.parents for root in roots)


def _normalise_app_label(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.casefold()).strip()


def _start_menu_shortcut(name: str) -> Path | None:
    """Resolve a display name from the user's or machine's Start Menu."""
    program_data = os.environ.get("ProgramData", r"C:\ProgramData")
    app_data = os.environ.get("APPDATA", "")
    roots = [
        Path(app_data) / "Microsoft" / "Windows" / "Start Menu" / "Programs",
        Path(program_data) / "Microsoft" / "Windows" / "Start Menu" / "Programs",
    ]
    requested = _normalise_app_label(name)
    if not requested:
        return None

    aliases = {
        "vscode": ("visual studio code", "vs code"),
        "edge": ("microsoft edge",),
        "chrome": ("google chrome",),
        "premiere": ("adobe premiere pro",),
        "premiere pro": ("adobe premiere pro",),
        "after effects": ("adobe after effects",),
        "photoshop": ("adobe photoshop",),
        "illustrator": ("adobe illustrator",),
    }
    labels = {requested, *(_normalise_app_label(alias) for alias in aliases.get(requested, ()))}
    exact: list[Path] = []
    partial: list[Path] = []
    for root in roots:
        if not root.is_dir():
            continue
        try:
            shortcuts = root.rglob("*.lnk")
            for shortcut in shortcuts:
                label = _normalise_app_label(shortcut.stem)
                if label in labels:
                    exact.append(shortcut)
                elif any(alias in label or label in alias for alias in labels if len(alias) >= 4):
                    partial.append(shortcut)
        except OSError:
            continue
    # Exact display-name matches win; a fuzzy match is safe only when unique.
    unique_exact = list(dict.fromkeys(exact))
    unique_partial = list(dict.fromkeys(partial))
    if len(unique_exact) == 1:
        return unique_exact[0]
    if not unique_exact and len(unique_partial) == 1:
        return unique_partial[0]
    if len(unique_exact) > 1 or len(unique_partial) > 1:
        raise HTTPException(status_code=409, detail=f"More than one Start Menu shortcut matches '{name}'. Use its full app name.")
    return None


def _resolve_application(body: AppRequest) -> Path:
    if body.executable_path:
        raw = Path(body.executable_path).expanduser()
        try:
            candidate = raw.resolve(strict=True)
        except OSError as exc:
            raise HTTPException(status_code=404, detail="The application executable was not found.") from exc
        if candidate.suffix.casefold() != ".exe" or not candidate.is_file() or not _is_under(candidate, _trusted_application_roots()):
            raise HTTPException(status_code=403, detail="The executable must be an existing .exe inside a user, Adobe, Program Files, or LocalAppData folder.")
        return candidate

    display_name = body.app.strip().strip("\"'")
    if not re.fullmatch(r"[\w .()+&'-]{1,100}", display_name, flags=re.UNICODE):
        raise HTTPException(status_code=400, detail="Enter an application name, not a command or file path.")
    name = _normalise_app_label(display_name)
    aliases = {"vs code": "vs code", "vscode": "vscode", "microsoft edge": "microsoft edge"}
    name = aliases.get(name, name)
    executable = APP_EXECUTABLES.get(name)
    roots = _trusted_application_roots()
    if executable:
        found = shutil.which(executable)
        if found:
            return Path(found).resolve()
    if executable and name in {"premiere", "premiere pro", "photoshop", "after effects", "illustrator"}:
        for root in roots:
            adobe = root / "Adobe"
            if not adobe.is_dir():
                continue
            for app_folder in adobe.iterdir():
                if not app_folder.is_dir():
                    continue
                candidates = list(app_folder.glob(executable)) + list(app_folder.glob(f"**/{executable}"))
                for candidate in candidates[:8]:
                    if candidate.is_file():
                        return candidate.resolve()
    common_candidates = {
        "vs code": [Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Microsoft VS Code" / (executable or "Code.exe")],
        "vscode": [Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Microsoft VS Code" / (executable or "Code.exe")],
        "chrome": [Path(os.environ.get("ProgramFiles", "")) / "Google/Chrome/Application" / (executable or "chrome.exe"),
                   Path(os.environ.get("ProgramFiles(x86)", "")) / "Google/Chrome/Application" / (executable or "chrome.exe")],
        "edge": [Path(os.environ.get("ProgramFiles(x86)", "")) / "Microsoft/Edge/Application/msedge.exe",
                 Path(os.environ.get("ProgramFiles", "")) / "Microsoft/Edge/Application/msedge.exe"],
        "microsoft edge": [Path(os.environ.get("ProgramFiles(x86)", "")) / "Microsoft/Edge/Application/msedge.exe",
                           Path(os.environ.get("ProgramFiles", "")) / "Microsoft/Edge/Application/msedge.exe"],
    }
    for candidate in common_candidates.get(name, []):
        if candidate.is_file():
            return candidate.resolve()
    shortcut = _start_menu_shortcut(display_name)
    if shortcut:
        return shortcut
    if executable:
        raise HTTPException(status_code=404, detail=f"{body.app} was not found in PATH, common install folders, or the Windows Start Menu.")
    raise HTTPException(status_code=404, detail=f"{body.app} was not found in the Windows Start Menu. Try its full Start Menu name.")


def _matching_processes(process_name: str):
    requested = Path(process_name.strip().strip('"')).name.casefold()
    if not requested.endswith(".exe"):
        requested += ".exe"
    if requested.removesuffix(".exe") in WINDOWS_BLOCKED_PROCESSES:
        raise HTTPException(status_code=403, detail="This operating-system process is protected.")
    return [proc for proc in psutil.process_iter(["pid", "name"]) if (proc.info.get("name") or "").casefold() == requested]


def _raise_window(hwnd: int) -> None:
    user32 = ctypes.windll.user32
    user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    user32.SetForegroundWindow(hwnd)


def _windows_for_process(pid: int) -> list[int]:
    if platform.system() != "Windows":
        return []
    hwnds: list[int] = []
    user32 = ctypes.windll.user32
    callback_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def callback(hwnd, _lparam):
        process_id = ctypes.c_ulong()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(process_id))
        if process_id.value == pid and user32.IsWindowVisible(hwnd):
            hwnds.append(int(hwnd))
        return True

    user32.EnumWindows(callback_type(callback), 0)
    return hwnds


def _start_ui_only() -> bool:
    global _last_ui_spawn
    if time.monotonic() - _last_ui_spawn < 5:
        return True
    port = int(os.environ.get("CARAXES_PORT", "8765"))
    repo_root = Path(__file__).resolve().parents[2]
    if getattr(sys, "frozen", False):
        argv = [sys.executable, "--ui-only", "--port", str(port)]
    else:
        pythonw = Path(sys.executable).with_name("pythonw.exe")
        executable = str(pythonw if pythonw.is_file() else Path(sys.executable))
        argv = [executable, str(repo_root / "desktop.py"), "--ui-only", "--port", str(port)]
    try:
        subprocess.Popen(argv, cwd=str(repo_root), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, shell=False)
        _last_ui_spawn = time.monotonic()
        return True
    except OSError:
        return False


def focus_caraxes_window() -> bool:
    if platform.system() != "Windows":
        return False
    user32 = ctypes.windll.user32
    match: list[int] = []
    callback_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def callback(hwnd, _lparam):
        length = user32.GetWindowTextLengthW(hwnd)
        if length:
            title = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, title, length + 1)
            if "caraxes" in title.value.casefold() and user32.IsWindowVisible(hwnd):
                match.append(int(hwnd))
        return True

    user32.EnumWindows(callback_type(callback), 0)
    if match:
        _raise_window(match[0])
        return True
    return _start_ui_only()


_last_ui_spawn = 0.0


@router.get("/system")
def system_status():
    return {
        **collect_diagnostics(),
        "brightness_percent": _get_brightness(),
        "volume": _get_volume(),
    }


@router.post("/apps/open")
def open_application(body: AppRequest):
    if platform.system() != "Windows":
        raise HTTPException(status_code=501, detail="Native app launching is currently implemented for Windows.")
    executable = _resolve_application(body)
    try:
        if executable.suffix.casefold() == ".lnk":
            os.startfile(str(executable))
        else:
            subprocess.Popen([str(executable)], shell=False, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Could not start the application: {exc}") from exc
    return {"ok": True, "app": body.app, "executable": str(executable)}


@router.post("/apps/focus")
def focus_application(body: ProcessRequest):
    if platform.system() != "Windows":
        raise HTTPException(status_code=501, detail="Native application focus is currently implemented for Windows.")
    processes = _matching_processes(body.process_name)
    for proc in processes:
        windows = _windows_for_process(proc.info["pid"])
        if windows:
            _raise_window(windows[0])
            return {"ok": True, "process": proc.info["name"], "focused": True}
    raise HTTPException(status_code=404, detail="No visible window was found for that running application.")


@router.post("/apps/close")
def close_application(body: CloseAppRequest):
    if not body.confirmed:
        raise HTTPException(status_code=409, detail="Confirm closing the named application; it may contain unsaved work.")
    if platform.system() != "Windows":
        raise HTTPException(status_code=501, detail="Native application close is currently implemented for Windows.")
    processes = _matching_processes(body.process_name)
    user32 = ctypes.windll.user32
    count = 0
    for proc in processes:
        for hwnd in _windows_for_process(proc.info["pid"]):
            user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE; let the application show its own save prompt.
            count += 1
    if not count:
        raise HTTPException(status_code=404, detail="No visible application window was found to close.")
    return {"ok": True, "windows_notified": count, "method": "WM_CLOSE"}


@router.post("/desktop/refresh")
def refresh_desktop():
    if platform.system() != "Windows":
        raise HTTPException(status_code=501, detail="Desktop refresh is currently implemented for Windows.")
    ctypes.windll.shell32.SHChangeNotify(0x08000000, 0x0000, None, None)
    return {"ok": True, "action": "shell-change-notification"}


@router.post("/terminal/execute")
def execute_terminal_command(body: TerminalRequest):
    """Run an explicitly prefixed user command as the current Windows account."""
    if platform.system() != "Windows":
        raise HTTPException(status_code=501, detail="Native terminal automation currently targets Windows.")
    command = body.command.strip()
    if not command:
        raise HTTPException(status_code=400, detail="Enter a command after 'terminal:'.")
    try:
        result = subprocess.run(
            ["cmd.exe", "/d", "/s", "/c", command],
            cwd=str(Path.home()),
            capture_output=True,
            text=True,
            errors="replace",
            timeout=45,
            check=False,
            shell=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(status_code=504, detail="Terminal command exceeded the 45-second limit. Use 'start' for a long-running app or process.") from exc
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Windows command processor could not start: {exc}") from exc
    return {
        "ok": result.returncode == 0,
        "exit_code": result.returncode,
        "stdout": result.stdout[-5000:],
        "stderr": result.stderr[-2000:],
        "identity": "current Windows user; no elevation requested",
    }


def _pyautogui():
    if platform.system() != "Windows":
        raise HTTPException(status_code=501, detail="Direct keyboard and mouse automation currently targets Windows.")
    try:
        import pyautogui
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.03
        return pyautogui
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Windows desktop automation is unavailable: {exc}") from exc


@router.post("/input/key")
def press_desktop_keys(body: KeypressRequest):
    automation = _pyautogui()
    aliases = {"windows": "win", "control": "ctrl", "escape": "esc", "return": "enter", "spacebar": "space"}
    keys = [aliases.get(key.strip().casefold(), key.strip().casefold()) for key in re.split(r"[+\s]+", body.keys) if key.strip()]
    valid = set(automation.KEYBOARD_KEYS)
    if not keys or len(keys) > 5 or any(key not in valid for key in keys):
        raise HTTPException(status_code=400, detail="Use supported key names such as 'win+r', 'ctrl+shift+esc', or 'enter'.")
    try:
        if len(keys) == 1:
            automation.press(keys[0])
        else:
            automation.hotkey(*keys)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Keyboard action failed: {exc}") from exc
    return {"ok": True, "keys": keys}


@router.post("/input/type")
def type_desktop_text(body: TypeTextRequest):
    automation = _pyautogui()
    if not body.text.isascii():
        raise HTTPException(status_code=400, detail="Keyboard typing currently accepts English/ASCII text. Paste Urdu text into the target app manually.")
    try:
        automation.write(body.text, interval=0.006)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Text entry failed: {exc}") from exc
    return {"ok": True, "characters_typed": len(body.text)}


@router.post("/input/click")
def click_desktop(body: ClickRequest):
    automation = _pyautogui()
    width, height = automation.size()
    if body.x >= width or body.y >= height:
        raise HTTPException(status_code=400, detail=f"Coordinates must be inside the {width}×{height} desktop.")
    try:
        automation.click(x=body.x, y=body.y, button=body.button, clicks=body.clicks, interval=0.1)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Mouse action failed: {exc}") from exc
    return {"ok": True, "x": body.x, "y": body.y, "button": body.button, "clicks": body.clicks}


def _with_volume_interface(operation):
    """Run a pycaw operation on a COM-initialized thread."""
    initialized = False
    try:
        from comtypes import CLSCTX_ALL, CoInitialize, CoUninitialize
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

        CoInitialize()
        initialized = True
        speakers = AudioUtilities.GetSpeakers()
        interface = speakers.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        return operation(cast(interface, POINTER(IAudioEndpointVolume)))
    finally:
        if initialized:
            try:
                CoUninitialize()
            except Exception:
                pass


def _send_media_key(virtual_key: int) -> None:
    user32 = ctypes.windll.user32
    key_up = 0x0002
    user32.keybd_event(virtual_key, 0, 0, 0)
    user32.keybd_event(virtual_key, 0, key_up, 0)


def _get_volume():
    try:
        return _with_volume_interface(lambda interface: {
            "available": True,
            "percent": round(interface.GetMasterVolumeLevelScalar() * 100),
            "muted": bool(interface.GetMute()),
            "method": "windows-core-audio",
        })
    except Exception as exc:
        return {"available": False, "error": str(exc)[:200]}


@router.post("/volume")
def set_volume(body: VolumeRequest):
    def apply(interface):
        if body.action == "set":
            if body.level is None:
                raise HTTPException(status_code=400, detail="A 0–100 level is required for set.")
            interface.SetMasterVolumeLevelScalar(body.level / 100, None)
        elif body.action == "up":
            interface.SetMasterVolumeLevelScalar(min(1, interface.GetMasterVolumeLevelScalar() + 0.05), None)
        elif body.action == "down":
            interface.SetMasterVolumeLevelScalar(max(0, interface.GetMasterVolumeLevelScalar() - 0.05), None)
        else:
            interface.SetMute(1 if body.action == "mute" else 0, None)
        return {
            "available": True,
            "percent": round(interface.GetMasterVolumeLevelScalar() * 100),
            "muted": bool(interface.GetMute()),
            "method": "windows-core-audio",
        }

    error = ""
    try:
        value = _with_volume_interface(apply)
    except HTTPException:
        raise
    except Exception as exc:
        value = None
        error = str(exc)[:180]
    if value is not None:
        return value
    # Media keys are a real Windows fallback for relative changes when the
    # Core Audio COM endpoint cannot be created on this machine/thread.
    if platform.system() == "Windows" and body.action in {"up", "down"}:
        for _ in range(3):
            _send_media_key(0xAF if body.action == "up" else 0xAE)
            time.sleep(0.04)
        return {"available": True, "percent": None, "muted": None, "method": "windows-media-key", "action": body.action}
    reason = f" Windows audio error: {error}." if error else ""
    raise HTTPException(status_code=503, detail=f"Windows Core Audio is unavailable.{reason} Relative volume up/down use Windows media keys as a fallback; exact level and mute controls need Core Audio support.")


def _powershell_output(script: str, *args: str) -> tuple[int, str, str] | None:
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script, *args],
            capture_output=True, text=True, timeout=12, check=False, shell=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def _get_brightness():
    if platform.system() != "Windows":
        return None
    script = "$b=@(Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightness -ErrorAction Stop); if($b.Count -eq 0){throw 'No WMI brightness sensor'}; (($b | ForEach-Object {[int]$_.CurrentBrightness}) -join ',')"
    result = _powershell_output(script)
    try:
        return int(result[1].split(",", 1)[0]) if result and result[0] == 0 and result[1] else None
    except (TypeError, ValueError):
        return None


@router.post("/brightness")
def set_brightness(body: BrightnessRequest):
    if platform.system() != "Windows":
        raise HTTPException(status_code=501, detail="Monitor brightness control is currently implemented for Windows laptops.")
    script = (
        f"$level = {body.level}; $monitors=@(Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightnessMethods -ErrorAction Stop); "
        "if($monitors.Count -eq 0){throw 'No WMI brightness controller is exposed by this display'}; "
        "$changed=0; foreach($monitor in $monitors){$reply=Invoke-CimMethod -InputObject $monitor -MethodName WmiSetBrightness -Arguments @{Timeout=1;Brightness=$level} -ErrorAction Stop; "
        "if($reply.ReturnValue -ne 0){throw ('Display brightness method returned ' + $reply.ReturnValue)}; $changed++}; "
        "Write-Output $changed"
    )
    result = _powershell_output(script)
    if result is None or result[0] != 0:
        detail = result[2] if result and result[2] else "No WMI brightness controller is exposed by this display."
        raise HTTPException(status_code=503, detail=f"Windows could not set brightness: {detail[:240]}")
    try:
        displays = int(result[1].splitlines()[-1])
    except (ValueError, IndexError):
        displays = 1
    return {"ok": True, "brightness_percent": body.level, "displays_changed": displays}


def change_brightness(body: BrightnessChangeRequest):
    current = _get_brightness()
    if current is None:
        raise HTTPException(status_code=503, detail="This Windows display does not expose a readable WMI brightness control.")
    level = min(100, current + 10) if body.direction == "up" else max(0, current - 10)
    return set_brightness(BrightnessRequest(level=level))


@router.post("/window/focus")
def focus_caraxes():
    focused = focus_caraxes_window()
    return {"ok": focused, "focused_or_started": focused}
