"""Dreamfyre language detection and optional OpenAI-compatible local AI bridge."""

from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request
from typing import Literal

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

router = APIRouter(prefix="/dreamfyre", tags=["Dreamfyre · AI"])

ROMAN_URDU_WORDS = {
    "yr", "yaar", "mujhe", "mujhy", "mujh", "mera", "meri", "mere", "ap", "aap", "tum",
    "kya", "hai", "hain", "ha", "kr", "karo", "kren", "kro", "bol", "bool", "jawab", "btao",
    "batao", "kitna", "kitni", "kholo", "chahiye", "chahie", "wala", "wali", "mein", "men",
    "ke", "ka", "ki", "ko", "se", "nhi", "nai", "haan", "acha", "ye", "iske", "andar",
    "par", "aur", "kyun", "kaise", "bana", "banao", "banado", "kardo", "do", "raha", "rha", "sakta",
    "barhao", "barha", "tez", "kam", "awaz", "band", "bnd", "roshni", "mitao", "hatao",
}


def detect_language(text: str) -> str:
    """Return en, ur, or ur-Latn (Roman Urdu)."""
    if re.search(r"[\u0600-\u06ff\u0750-\u077f\u08a0-\u08ff]", text):
        return "ur"
    words = set(re.findall(r"[a-z]+", text.casefold()))
    matches = len(words & ROMAN_URDU_WORDS)
    return "ur-Latn" if matches >= 2 or (matches == 1 and len(words) <= 4) else "en"


def response_language_name(language: str) -> str:
    return {"ur": "Urdu", "ur-Latn": "Roman Urdu", "en": "English"}.get(language, "English")


def localize_command_message(message: str, language: str, data: dict | None = None) -> str:
    if language == "en":
        return message
    roman = language == "ur-Latn"
    if message.startswith("System status.") and data:
        battery = data.get("battery")
        battery_part = (
            f"Battery {battery['percent']} percent, {'plugged in' if battery['plugged'] else 'on battery'}"
            if battery else "battery status unavailable"
        )
        if roman:
            battery_part = (
                f"battery {battery['percent']} feesad, {'charger laga hua hai' if battery['plugged'] else 'battery par chal raha hai'}"
                if battery else "battery status dastiyab nahin"
            )
            return (
                f"System ki surat-e-haal: CPU {round(data['cpu_percent'])} feesad; RAM {round(data['memory_percent'])} feesad; "
                f"{battery_part}; {len(data['network']['connected_interfaces'])} active network interfaces; "
                f"Wi-Fi {'connected hai' if data.get('wifi', {}).get('connected') else 'connected nahin hai'}."
            )
        battery_part = (
            f"بیٹری {battery['percent']} فیصد، {'چارجر لگا ہوا ہے' if battery['plugged'] else 'بیٹری پر چل رہی ہے'}"
            if battery else "بیٹری کی معلومات دستیاب نہیں"
        )
        return (
            f"سسٹم کی صورتحال: سی پی یو {round(data['cpu_percent'])} فیصد؛ ریم {round(data['memory_percent'])} فیصد؛ "
            f"{battery_part}؛ فعال نیٹ ورک انٹرفیس {len(data['network']['connected_interfaces'])}؛ "
            f"وائی فائی {'منسلک ہے' if data.get('wifi', {}).get('connected') else 'منسلک نہیں ہے'}۔"
        )
    if message.startswith("Opened "):
        target = message.removeprefix("Opened ").removesuffix(" in the default browser.")
        return f"{target} browser mein khol diya." if roman else f"{target} براؤزر میں کھول دیا۔"
    if message.startswith("Launched "):
        target = message.removeprefix("Launched ").removesuffix(".")
        return f"{target} launch kar diya." if roman else f"{target} کھول دیا۔"
    if message.startswith("Found ") and data is not None:
        count = len(data.get("files", []))
        return f"{count} matching files milin." if roman else f"{count} ملتی جلتی فائلیں ملیں۔"
    if message.startswith("No matching filenames"):
        return "Koi milti file nahin mili." if roman else "کوئی ملتی جلتی فائل نہیں ملی۔"
    if message.startswith("I can control apps"):
        return (
            "Main apps, volume, brightness, keyboard, mouse, files aur Windows terminal control kar sakta hoon; system status aur web search bhi."
            if roman else "میں ایپس، والیوم، برائٹنس، کی بورڈ، ماؤس، فائلیں اور ونڈوز ٹرمینل کنٹرول کر سکتا ہوں؛ سسٹم اسٹیٹس اور ویب سرچ بھی۔"
        )
    if message.startswith("Pressed "):
        keys = message.removeprefix("Pressed ").removesuffix(".")
        return f"{keys} keys press kar diye." if roman else f"{keys} کیز دبا دی ہیں۔"
    if message.startswith("Typed "):
        count = re.search(r"\d+", message)
        return f"Active window mein {count.group(0) if count else ''} characters type kar diye." if roman else f"فعال ونڈو میں {count.group(0) if count else ''} حروف لکھ دیے۔"
    if message.startswith("Clicked desktop at "):
        return "Desktop par click kar diya." if roman else "ڈیسک ٹاپ پر کلک کر دیا۔"
    if message.startswith("Focused "):
        app = message.removeprefix("Focused ").removesuffix(".")
        return f"{app} par focus kar diya." if roman else f"{app} کو سامنے لے آیا۔"
    if message.startswith("Asked "):
        return "App ko band hone ka kaha hai; unsaved kaam ke liye save prompt aa sakta hai." if roman else "ایپ کو بند ہونے کا کہا ہے؛ غیر محفوظ کام کے لیے محفوظ کرنے کا پیغام آ سکتا ہے۔"
    if message == "Desktop refreshed.":
        return "Desktop refresh kar diya." if roman else "ڈیسک ٹاپ ریفریش کر دیا۔"
    if message.startswith("Volume set to ") or message.startswith("Volume is "):
        value = re.search(r"(\d+) percent", message)
        percent = value.group(1) if value else "?"
        return f"Volume {percent} feesad hai." if roman else f"والیوم {percent} فیصد ہے۔"
    if message.startswith("Volume up command sent"):
        return "Awaz barhane ka hukm bhej diya." if roman else "آواز بڑھانے کا حکم بھیج دیا۔"
    if message.startswith("Volume down command sent"):
        return "Awaz kam karne ka hukm bhej diya." if roman else "آواز کم کرنے کا حکم بھیج دیا۔"
    if message.startswith("Brightness set to "):
        value = re.search(r"(\d+) percent", message)
        percent = value.group(1) if value else "?"
        return f"Brightness {percent} feesad kar di." if roman else f"برائٹنس {percent} فیصد کر دی۔"
    if message.startswith("Created "):
        return "File ya folder bana diya." if roman else "فائل یا فولڈر بنا دیا۔"
    if message.startswith("Renamed "):
        return "Naam tabdeel kar diya." if roman else "نام تبدیل کر دیا۔"
    if message.startswith("Moved ") and "Recycle Bin" in message:
        return "Item Recycle Bin mein bhej diya." if roman else "آئٹم ری سائیکل بن میں بھیج دیا۔"
    return message


class AskRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=12000)
    mode: Literal["chat", "coding", "academic"] = "chat"


def _system_prompt(mode: str, language: str) -> str:
    lang = response_language_name(language)
    style = "Urdu script" if language == "ur" else "Roman Urdu" if language == "ur-Latn" else "English"
    base = f"Answer in {style}. The user's input language is {lang}."
    if mode == "coding":
        return base + (
            " Act as a senior software engineer. Return complete, runnable code for the requested scope, with every file and setup step needed. "
            "Do not use ellipses, TODOs, fake APIs, omitted sections, or placeholder functions. State any assumptions, and say clearly if a request is underspecified."
        )
    if mode == "academic":
        return base + (
            " Act as an exact academic tutor. Show definitions, assumptions, equations, intermediate steps, units, and a checked final result. "
            "If a problem statement lacks necessary information, identify it instead of inventing values."
        )
    return base + " Be precise, useful, and honest about uncertainty."


def _chat_completion(messages: list[dict[str, str]], max_tokens: int = 12000) -> tuple[str, str]:
    base_url = os.environ.get("CARAXES_LLM_BASE_URL", "http://127.0.0.1:11434/v1").rstrip("/")
    if not base_url.startswith(("http://", "https://")):
        raise HTTPException(status_code=500, detail="CARAXES_LLM_BASE_URL must be an HTTP(S) URL.")
    model = os.environ.get("CARAXES_LLM_MODEL", "qwen2.5-coder:7b")
    payload = json.dumps({"model": model, "messages": messages, "max_tokens": max_tokens, "stream": False}).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    api_key = os.environ.get("CARAXES_LLM_API_KEY")
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    request = urllib.request.Request(f"{base_url}/chat/completions", data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=180) as response:
            result = json.loads(response.read(16 * 1024 * 1024))
    except urllib.error.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Configured AI endpoint returned HTTP {exc.code}.") from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise HTTPException(
            status_code=503,
            detail="AI model unavailable. Start a local OpenAI-compatible server (default: Ollama on 127.0.0.1:11434) or configure CARAXES_LLM_BASE_URL.",
        ) from exc
    try:
        choice = result["choices"][0]
        content = choice["message"]["content"]
        reason = str(choice.get("finish_reason", "stop"))
    except (KeyError, IndexError, TypeError) as exc:
        raise HTTPException(status_code=502, detail="AI endpoint returned an unsupported chat-completion response.") from exc
    if not isinstance(content, str) or not content.strip():
        raise HTTPException(status_code=502, detail="AI endpoint returned an empty response.")
    return content.strip(), reason


def generate_answer(prompt: str, mode: str = "chat") -> tuple[str, str]:
    language = detect_language(prompt)
    messages = [{"role": "system", "content": _system_prompt(mode, language)}, {"role": "user", "content": prompt}]
    answer, finish_reason = _chat_completion(messages)
    if finish_reason == "length":
        messages.append({"role": "assistant", "content": answer})
        messages.append({"role": "user", "content": "Continue exactly from the last character. Do not repeat prior text. Finish the answer and all code blocks completely."})
        continuation, finish_reason = _chat_completion(messages)
        answer += continuation
    if finish_reason == "length":
        raise HTTPException(status_code=502, detail="The configured model still hit its output limit after continuation. Raise the model context/output limit and retry.")
    return answer, language


@router.post("/ask")
def ask(body: AskRequest):
    answer, language = generate_answer(body.prompt, body.mode)
    return {"message": answer, "language": language, "mode": body.mode, "complete": True}
