"""Syrax roster endpoints retained for dashboard integrations."""

from fastapi import APIRouter

router = APIRouter(prefix="/syrax", tags=["Syrax · Control UI"])

DRAGON_ROSTER = [
    {"name": "Caraxes", "role": "Core brain · code generation"},
    {"name": "Syrax", "role": "Master control UI"},
    {"name": "Vhagar", "role": "Security · privacy guard"},
    {"name": "Balerion", "role": "OS automation"},
    {"name": "Meleys", "role": "System diagnostics"},
    {"name": "Vermithor", "role": "Local data vault"},
    {"name": "Silverwing", "role": "UI · themes"},
    {"name": "Seasmoke", "role": "Network · web access"},
    {"name": "Sunfyre", "role": "Media rendering"},
    {"name": "Dreamfyre", "role": "AI · multilingual learning"},
    {"name": "Vermax", "role": "Task scheduler"},
    {"name": "Arrax", "role": "Encryption guard"},
    {"name": "Tyraxes", "role": "File management"},
    {"name": "Moondancer", "role": "Speech · audio"},
    {"name": "The Cannibal", "role": "Garbage collection"},
    {"name": "Tessarion", "role": "Adobe Creative Cloud automation"},
]


@router.get("/roster")
def roster():
    return {"count": len(DRAGON_ROSTER), "dragons": DRAGON_ROSTER}
