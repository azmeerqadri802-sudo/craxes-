"""Moondancer speech settings for Windows/WebView's installed system voices."""

from __future__ import annotations

from fastapi import APIRouter
from pydantic import BaseModel, Field

from backend.modules.dreamfyre_ai import detect_language

router = APIRouter(prefix="/moondancer", tags=["Moondancer · Voice"])


class SpeechRequest(BaseModel):
    text: str = Field(min_length=1, max_length=12000)
    language: str | None = Field(default=None, max_length=12)


@router.post("/prepare")
def prepare_speech(body: SpeechRequest):
    language = body.language or detect_language(body.text)
    tag = "ur-PK" if language.startswith("ur") else "en-US"
    return {
        "text": body.text,
        "language": language,
        "voice_language": tag,
        "rate": 0.92,
        "pitch": 0.82,
        "engine": "Windows WebView2 system speech voices",
    }
