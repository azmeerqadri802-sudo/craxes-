"""Shared local path policy and data-directory helpers."""

from __future__ import annotations

import os
from pathlib import Path

from fastapi import HTTPException


def allowed_roots() -> list[Path]:
    configured = os.environ.get("CARAXES_ALLOWED_ROOTS", "").strip()
    roots = [Path(part).expanduser() for part in configured.split(os.pathsep) if part.strip()]
    if not roots:
        roots = [Path.home()]
    resolved: list[Path] = []
    for root in roots:
        try:
            candidate = root.resolve()
        except OSError:
            continue
        if candidate.is_dir() and candidate not in resolved:
            resolved.append(candidate)
    return resolved


def resolve_user_path(raw_path: str, *, must_exist: bool = False, allow_root: bool = False) -> Path:
    """Resolve a user-selected path beneath configured CARAXES roots."""
    if not raw_path or len(raw_path) > 2048:
        raise HTTPException(status_code=400, detail="Provide a path up to 2048 characters.")
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = Path.home() / path
    try:
        resolved = path.resolve(strict=must_exist)
    except (OSError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail="The requested path cannot be resolved.") from exc
    roots = allowed_roots()
    if not any(resolved == root or root in resolved.parents for root in roots):
        raise HTTPException(status_code=403, detail="This path is outside CARAXES allowed roots.")
    if not allow_root and resolved in roots:
        raise HTTPException(status_code=400, detail="Choose an item inside an allowed root.")
    if must_exist and not resolved.exists():
        raise HTTPException(status_code=404, detail="The requested path does not exist.")
    return resolved


def caraxes_data_dir(*parts: str) -> Path:
    base = Path(os.environ.get("LOCALAPPDATA", Path.home() / ".local" / "share")) / "CARAXES"
    target = base.joinpath(*parts)
    target.mkdir(parents=True, exist_ok=True)
    return target
