"""Caraxes code-generation and academic-partner endpoints."""

from typing import Literal

from fastapi import APIRouter
from pydantic import BaseModel, Field

from backend.modules.dreamfyre_ai import generate_answer

router = APIRouter(prefix="/caraxes", tags=["Caraxes · Core Brain"])


class CoreRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=12000)


@router.post("/code")
def generate_code(body: CoreRequest):
    answer, language = generate_answer(body.prompt, "coding")
    return {"message": answer, "language": language, "complete": True}


@router.post("/learn")
def study_partner(body: CoreRequest):
    answer, language = generate_answer(body.prompt, "academic")
    return {"message": answer, "language": language, "complete": True}
