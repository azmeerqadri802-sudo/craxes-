"""CARAXES local command service.

The API intentionally exposes named, bounded capabilities instead of an
arbitrary shell, Python evaluator, or root command endpoint.
"""

from __future__ import annotations

import os
import platform
import re
import shutil
import subprocess
import threading
import time
import urllib.parse
import webbrowser
from pathlib import Path
from typing import Any

import psutil
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field


ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend"
DIST = FRONTEND / "dist"
MAX_BODY_BYTES = 4096
MAX_SEARCH_DIRS = 1200
MAX_RESULTS = 20

app = FastAPI(title="CARAXES Local Core", version="1.0.0", docs_url=None, redoc_url=None)
state_lock = threading.Lock()
state: dict[str, Any] = {
    "wake_sequence": 0,
    "last_wake": None,
    "last_action": "Core standing by.",
    "listener_seen_at": None,
    "listener_status": "offline",
    "listener_error": None,
}


class Command(BaseModel):
    text: str = Field(min_length=1, max_length=500)


class WakeEvent(BaseModel):
    source: str = Field(default="listener", max_length=40)


class ListenerStatus(BaseModel):
    status: str = Field(pattern="^(starting|online|offline)$")
    error: str | None = Field(default=None, max_length=300)


@app.middleware("http")
async def local_only(request: Request, call_next):
    """Bind the service to loopback and reject browser cross-origin requests."""
    host_header = request.headers.get("host", "")
    if host_header.startswith("[") and "]" in host_header:
        host = host_header[1 : host_header.index("]")].lower()
    else:
        host = host_header.rsplit(":", 1)[0].lower()
    if host not in {"127.0.0.1", "localhost", "::1"}:
        return JSONResponse(status_code=403, content={"detail": "Local connections only"})
    origin = request.headers.get("origin")
    allowed_origins = {
        "http://127.0.0.1:8765", "http://localhost:8765",
        "http://127.0.0.1:5173", "http://localhost:5173",
    }
    extra_origin = os.environ.get("CARAXES_ALLOWED_ORIGIN")
    if extra_origin:
        allowed_origins.add(extra_origin)
    if origin and origin not in allowed_origins:
        return JSONResponse(status_code=403, content={"detail": "Cross-origin request denied"})
    length = request.headers.get("content-length")
    if length and length.isdigit() and int(length) > MAX_BODY_BYTES:
        return JSONResponse(status_code=413, content={"detail": "Request too large"})
    return await call_next(request)


def set_last_action(message: str) -> None:
    with state_lock:
        state["last_action"] = message


def diagnostics() -> dict[str, Any]:
    battery = None
    try:
        item = psutil.sensors_battery()
        if item is not None:
            battery = {"percent": round(item.percent), "plugged": item.power_plugged}
    except (AttributeError, OSError):
        pass

    net = psutil.net_if_stats()
    active = [name for name, info in net.items() if info.isup and name.lower() not in {"lo", "loopback"}]
    counters = psutil.net_io_counters()
    return {
        "platform": platform.system(),
        "cpu_percent": psutil.cpu_percent(interval=0.15),
        "memory_percent": psutil.virtual_memory().percent,
        "memory_used_gb": round(psutil.virtual_memory().used / (1024**3), 1),
        "memory_total_gb": round(psutil.virtual_memory().total / (1024**3), 1),
        "battery": battery,
        "network": {"connected_interfaces": active, "bytes_sent": counters.bytes_sent, "bytes_received": counters.bytes_recv},
        "sampled_at": time.time(),
    }


def open_safe_url(url: str) -> str:
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise HTTPException(status_code=400, detail="Only public HTTPS pages can be opened.")
    host = parsed.hostname.lower().rstrip(".")
    if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        raise HTTPException(status_code=400, detail="Local network addresses are not allowed.")
    if re.fullmatch(r"(?:0x[0-9a-f]+|[0-9.]+)", host, flags=re.IGNORECASE):
        raise HTTPException(status_code=400, detail="Numeric IP address forms are not allowed.")
    try:
        import ipaddress

        ip = ipaddress.ip_address(host.strip("[]"))
        if not ip.is_global:
            raise HTTPException(status_code=400, detail="Private network addresses are not allowed.")
    except ValueError:
        pass
    webbrowser.open(url, new=2)
    return f"Opened {host} in the default browser."


APP_CATALOG: dict[str, dict[str, list[str]]] = {
    "windows": {
        "notepad": ["notepad.exe"],
        "calculator": ["calc.exe"],
        "paint": ["mspaint.exe"],
    },
    "darwin": {
        "notepad": ["open", "-a", "TextEdit"],
        "calculator": ["open", "-a", "Calculator"],
    },
    "linux": {
        "notepad": ["gedit"],
        "calculator": ["gnome-calculator"],
    },
}


def launch_app(name: str) -> str:
    system = platform.system().lower()
    catalog = APP_CATALOG.get(system, {})
    argv = catalog.get(name.lower())
    if not argv:
        raise HTTPException(status_code=400, detail=f"'{name}' is not in the built-in app allowlist.")
    executable = argv[0]
    if system != "windows" and shutil.which(executable) is None:
        raise HTTPException(status_code=404, detail=f"The allowlisted app '{name}' is not installed.")
    try:
        subprocess.Popen(argv, shell=False, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Could not launch {name}: {exc}") from exc
    return f"Launched {name.title()}."


def search_files(name: str) -> list[str]:
    """Search filenames only in common personal folders, with strict bounds."""
    needle = name.casefold().strip()
    if not needle or len(needle) > 120:
        raise HTTPException(status_code=400, detail="Enter a filename fragment up to 120 characters.")
    home = Path.home()
    roots = [home / folder for folder in ("Documents", "Downloads", "Desktop")]
    found: list[str] = []
    scanned = 0
    for root in roots:
        if not root.is_dir():
            continue
        for directory, subdirs, files in os.walk(root, followlinks=False):
            subdirs[:] = [d for d in subdirs if not d.startswith(".")]
            scanned += 1
            for filename in files:
                if needle in filename.casefold():
                    found.append(str(Path(directory) / filename))
                    if len(found) >= MAX_RESULTS:
                        return found
            if scanned >= MAX_SEARCH_DIRS:
                return found
    return found


def run_command(raw_text: str) -> dict[str, Any]:
    text = raw_text.strip()
    normalized = re.sub(r"\s+", " ", text).casefold()

    if normalized in {"diagnostics", "system status", "system diagnostics", "battery", "how is my system"}:
        snapshot = diagnostics()
        battery = snapshot["battery"]
        battery_text = (
            f"Battery {battery['percent']} percent, {'plugged in' if battery['plugged'] else 'on battery'}"
            if battery else "battery status unavailable"
        )
        interfaces = snapshot["network"]["connected_interfaces"]
        network_text = f"{len(interfaces)} active network {'interface' if len(interfaces) == 1 else 'interfaces'}"
        message = (
            f"System status. CPU {round(snapshot['cpu_percent'])} percent. "
            f"Memory {round(snapshot['memory_percent'])} percent. {battery_text}. {network_text}."
        )
        return {"message": message, "data": snapshot}

    youtube = re.fullmatch(r"(?:search|play) youtube(?: for)?\s+(.+)", text, flags=re.IGNORECASE)
    if youtube:
        query = youtube.group(1).strip()
        if not query or len(query) > 180:
            raise HTTPException(status_code=400, detail="YouTube searches must be 1–180 characters.")
        url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(query)
        return {"message": open_safe_url(url), "data": {"query": query}}

    open_match = re.fullmatch(r"open\s+(youtube|google|wikipedia)", normalized)
    if open_match:
        sites = {"youtube": "https://www.youtube.com", "google": "https://www.google.com", "wikipedia": "https://www.wikipedia.org"}
        return {"message": open_safe_url(sites[open_match.group(1)]), "data": None}

    url_match = re.fullmatch(r"open\s+(https://\S+)", text, flags=re.IGNORECASE)
    if url_match:
        return {"message": open_safe_url(url_match.group(1)), "data": None}

    app_match = re.fullmatch(r"(?:launch|open)\s+(notepad|calculator|paint)", normalized)
    if app_match:
        return {"message": launch_app(app_match.group(1)), "data": None}

    find_match = re.fullmatch(r"(?:find|search for)\s+(?:file\s+)?(.+)", text, flags=re.IGNORECASE)
    if find_match:
        results = search_files(find_match.group(1))
        message = f"Found {len(results)} matching filename(s) in Documents, Downloads, and Desktop." if results else "No matching filenames found in Documents, Downloads, or Desktop."
        return {"message": message, "data": {"files": results}}

    return {
        "message": "I can sample diagnostics, open YouTube/Google/Wikipedia or a public HTTPS page, search YouTube, launch Notepad/Calculator/Paint, and find filenames in Documents, Downloads, or Desktop.",
        "data": {"accepted": False},
    }


@app.get("/api/health")
def health():
    return {"ok": True, "service": "CARAXES Local Core", "version": app.version}


@app.get("/api/state")
def get_state():
    with state_lock:
        return dict(state)


@app.post("/api/wake")
def wake(event: WakeEvent):
    with state_lock:
        state["wake_sequence"] += 1
        state["last_wake"] = {"source": event.source, "at": time.time()}
    return {"ok": True, "wake_sequence": state["wake_sequence"]}


@app.post("/api/listener/heartbeat")
def listener_heartbeat():
    with state_lock:
        state["listener_seen_at"] = time.time()
        state["listener_status"] = "online"
        state["listener_error"] = None
    return {"ok": True}


@app.post("/api/listener/status")
def listener_status(update: ListenerStatus):
    with state_lock:
        state["listener_status"] = update.status
        state["listener_error"] = update.error
        if update.status != "online":
            state["listener_seen_at"] = None
    return {"ok": True}


@app.get("/api/diagnostics")
def get_diagnostics():
    return diagnostics()


@app.post("/api/command")
def command(body: Command):
    result = run_command(body.text)
    set_last_action(result["message"])
    return result


@app.get("/")
def index():
    if not (DIST / "index.html").is_file():
        return JSONResponse(
            status_code=503,
            content={"detail": "Frontend is not built. See README.md and run npm install, then npm run build in the frontend directory."},
        )
    return FileResponse(DIST / "index.html")


@app.get("/{asset_path:path}")
def assets(asset_path: str):
    candidate = (DIST / asset_path).resolve()
    if DIST.resolve() not in candidate.parents or not candidate.is_file():
        raise HTTPException(status_code=404, detail="Not found")
    return FileResponse(candidate)
