"""CARAXES local command service.

The API intentionally exposes named, bounded capabilities instead of an
arbitrary shell, Python evaluator, or root command endpoint.
"""

from __future__ import annotations

import os
import platform
import re
import shutil
import subprocess
import threading
import time
import urllib.parse
import webbrowser
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

from backend.modules.balerion_automation import (
    AppRequest, BrightnessRequest, CloseAppRequest, ProcessRequest, VolumeRequest,
    close_application, focus_application, focus_caraxes_window, open_application,
    refresh_desktop, router as balerion_router, set_brightness, set_volume,
)
from backend.modules.caraxes_core import router as caraxes_router
from backend.modules.dreamfyre_ai import detect_language, generate_answer, localize_command_message, router as dreamfyre_router
from backend.modules.meleys_diagnostics import collect_diagnostics, router as meleys_router
from backend.modules.moondancer_voice import router as moondancer_router
from backend.modules.syrax_ui import router as syrax_router
from backend.modules.tessarion_creative import router as tessarion_router
from backend.modules.tyraxes_files import (
    CreateRequest, DeleteRequest, RenameRequest, create_file_or_folder,
    delete_file_or_folder, rename_file_or_folder, router as tyraxes_router,
)


ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend"
DIST = FRONTEND / "dist"
MAX_BODY_BYTES = 128 * 1024
MAX_SEARCH_DIRS = 1200
MAX_RESULTS = 20

app = FastAPI(title="CARAXES Local Core", version="1.0.0", docs_url=None, redoc_url=None)
state_lock = threading.Lock()
state: dict[str, Any] = {
    "wake_sequence": 0,
    "last_wake": None,
    "last_action": "Core standing by.",
    "last_language": "en",
    "listener_seen_at": None,
    "listener_status": "offline",
    "listener_error": None,
}

for module_router in (
    syrax_router,
    meleys_router,
    caraxes_router,
    dreamfyre_router,
    moondancer_router,
    balerion_router,
    tyraxes_router,
    tessarion_router,
):
    app.include_router(module_router)


class Command(BaseModel):
    text: str = Field(min_length=1, max_length=500)


class WakeEvent(BaseModel):
    source: str = Field(default="listener", max_length=40)


class ListenerStatus(BaseModel):
    status: str = Field(pattern="^(starting|online|offline)$")
    error: str | None = Field(default=None, max_length=300)


@app.middleware("http")
async def local_only(request: Request, call_next):
    """Bind the service to loopback and reject browser cross-origin requests."""
    host_header = request.headers.get("host", "")
    if host_header.startswith("[") and "]" in host_header:
        host = host_header[1 : host_header.index("]")].lower()
    else:
        host = host_header.rsplit(":", 1)[0].lower()
    if host not in {"127.0.0.1", "localhost", "::1"}:
        return JSONResponse(status_code=403, content={"detail": "Local connections only"})
    origin = request.headers.get("origin")
    allowed_origins = {
        "http://127.0.0.1:8765", "http://localhost:8765",
        "http://127.0.0.1:5173", "http://localhost:5173",
    }
    extra_origin = os.environ.get("CARAXES_ALLOWED_ORIGIN")
    if extra_origin:
        allowed_origins.add(extra_origin)
    if origin and origin not in allowed_origins:
        return JSONResponse(status_code=403, content={"detail": "Cross-origin request denied"})
    length = request.headers.get("content-length")
    if length and length.isdigit() and int(length) > MAX_BODY_BYTES:
        return JSONResponse(status_code=413, content={"detail": "Request too large"})
    return await call_next(request)


def set_last_action(message: str, language: str = "en") -> None:
    with state_lock:
        state["last_action"] = message
        state["last_language"] = language


def diagnostics() -> dict[str, Any]:
    return collect_diagnostics()


def open_safe_url(url: str) -> str:
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise HTTPException(status_code=400, detail="Only public HTTPS pages can be opened.")
    host = parsed.hostname.lower().rstrip(".")
    if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        raise HTTPException(status_code=400, detail="Local network addresses are not allowed.")
    if re.fullmatch(r"(?:0x[0-9a-f]+|[0-9.]+)", host, flags=re.IGNORECASE):
        raise HTTPException(status_code=400, detail="Numeric IP address forms are not allowed.")
    try:
        import ipaddress

        ip = ipaddress.ip_address(host.strip("[]"))
        if not ip.is_global:
            raise HTTPException(status_code=400, detail="Private network addresses are not allowed.")
    except ValueError:
        pass
    webbrowser.open(url, new=2)
    return f"Opened {host} in the default browser."


APP_CATALOG: dict[str, dict[str, list[str]]] = {
    "windows": {
        "notepad": ["notepad.exe"],
        "calculator": ["calc.exe"],
        "paint": ["mspaint.exe"],
    },
    "darwin": {
        "notepad": ["open", "-a", "TextEdit"],
        "calculator": ["open", "-a", "Calculator"],
    },
    "linux": {
        "notepad": ["gedit"],
        "calculator": ["gnome-calculator"],
    },
}


def launch_app(name: str) -> str:
    system = platform.system().lower()
    catalog = APP_CATALOG.get(system, {})
    argv = catalog.get(name.lower())
    if not argv:
        raise HTTPException(status_code=400, detail=f"'{name}' is not in the built-in app allowlist.")
    executable = argv[0]
    if system != "windows" and shutil.which(executable) is None:
        raise HTTPException(status_code=404, detail=f"The allowlisted app '{name}' is not installed.")
    try:
        subprocess.Popen(argv, shell=False, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Could not launch {name}: {exc}") from exc
    return f"Launched {name.title()}."


def search_files(name: str) -> list[str]:
    """Search filenames only in common personal folders, with strict bounds."""
    needle = name.casefold().strip()
    if not needle or len(needle) > 120:
        raise HTTPException(status_code=400, detail="Enter a filename fragment up to 120 characters.")
    home = Path.home()
    roots = [home / folder for folder in ("Documents", "Downloads", "Desktop")]
    found: list[str] = []
    scanned = 0
    for root in roots:
        if not root.is_dir():
            continue
        for directory, subdirs, files in os.walk(root, followlinks=False):
            subdirs[:] = [d for d in subdirs if not d.startswith(".")]
            scanned += 1
            for filename in files:
                if needle in filename.casefold():
                    found.append(str(Path(directory) / filename))
                    if len(found) >= MAX_RESULTS:
                        return found
            if scanned >= MAX_SEARCH_DIRS:
                return found
    return found


def run_command(raw_text: str) -> dict[str, Any]:
    text = raw_text.strip()
    normalized = re.sub(r"\s+", " ", text).casefold()

    if normalized in {"diagnostics", "system status", "system diagnostics", "battery", "how is my system"}:
        snapshot = diagnostics()
        battery = snapshot["battery"]
        battery_text = (
            f"Battery {battery['percent']} percent, {'plugged in' if battery['plugged'] else 'on battery'}"
            if battery else "battery status unavailable"
        )
        interfaces = snapshot["network"]["connected_interfaces"]
        network_text = f"{len(interfaces)} active network {'interface' if len(interfaces) == 1 else 'interfaces'}"
        wifi_text = "Wi-Fi connected" if snapshot["wifi"]["connected"] else "Wi-Fi disconnected"
        message = (
            f"System status. CPU {round(snapshot['cpu_percent'])} percent. "
            f"Memory {round(snapshot['memory_percent'])} percent. {battery_text}. {network_text}. {wifi_text}."
        )
        return {"message": message, "data": snapshot}

    youtube = re.fullmatch(r"(?:search|play) youtube(?: for)?\s+(.+)", text, flags=re.IGNORECASE)
    if youtube:
        query = youtube.group(1).strip()
        if not query or len(query) > 180:
            raise HTTPException(status_code=400, detail="YouTube searches must be 1–180 characters.")
        url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(query)
        return {"message": open_safe_url(url), "data": {"query": query}}

    open_match = re.fullmatch(r"open\s+(youtube|google|wikipedia)", normalized)
    if open_match:
        sites = {"youtube": "https://www.youtube.com", "google": "https://www.google.com", "wikipedia": "https://www.wikipedia.org"}
        return {"message": open_safe_url(sites[open_match.group(1)]), "data": None}

    url_match = re.fullmatch(r"open\s+(https://\S+)", text, flags=re.IGNORECASE)
    if url_match:
        return {"message": open_safe_url(url_match.group(1)), "data": None}

    app_match = re.fullmatch(r"(?:launch|open)\s+(notepad|calculator|paint|photoshop|premiere(?: pro)?|after effects|illustrator|chrome|vs code|vscode)", normalized)
    if app_match:
        result = open_application(AppRequest(app=app_match.group(1)))
        return {"message": f"Launched {app_match.group(1).title()}.", "data": result}

    app_processes = {
        "premiere": "Adobe Premiere Pro.exe", "premiere pro": "Adobe Premiere Pro.exe",
        "photoshop": "Photoshop.exe", "after effects": "AfterFX.exe", "illustrator": "Illustrator.exe",
        "vs code": "Code.exe", "vscode": "Code.exe", "chrome": "chrome.exe",
        "calculator": "CalculatorApp.exe", "notepad": "notepad.exe", "paint": "mspaint.exe",
    }
    process_match = re.fullmatch(r"focus\s+(?:app\s+)?(.+)", normalized)
    if process_match and process_match.group(1) in app_processes:
        result = focus_application(ProcessRequest(process_name=app_processes[process_match.group(1)]))
        return {"message": f"Focused {process_match.group(1).title()}.", "data": result}
    close_match = re.fullmatch(r"close\s+(?:app\s+)?(.+)", normalized)
    if close_match and close_match.group(1) in app_processes:
        result = close_application(CloseAppRequest(process_name=app_processes[close_match.group(1)], confirmed=True))
        return {"message": f"Asked {close_match.group(1).title()} to close; it may prompt to save work.", "data": result}

    if normalized == "refresh desktop":
        return {"message": "Desktop refreshed.", "data": refresh_desktop()}

    volume_set = re.fullmatch(r"volume\s+(?:set\s+)?(\d{1,3})", normalized)
    if volume_set:
        result = set_volume(VolumeRequest(action="set", level=int(volume_set.group(1))))
        return {"message": f"Volume set to {result['percent']} percent.", "data": result}
    volume_action = re.fullmatch(r"volume\s+(up|down|mute|unmute)", normalized)
    if volume_action:
        result = set_volume(VolumeRequest(action=volume_action.group(1)))
        return {"message": f"Volume is {result['percent']} percent.", "data": result}
    brightness = re.fullmatch(r"brightness\s+(?:set\s+)?(\d{1,3})", normalized)
    if brightness:
        result = set_brightness(BrightnessRequest(level=int(brightness.group(1))))
        return {"message": f"Brightness set to {result['brightness_percent']} percent.", "data": result}

    create_match = re.fullmatch(r"create\s+(file|folder)\s+(.+)", text, flags=re.IGNORECASE)
    if create_match:
        kind, path = create_match.groups()
        result = create_file_or_folder(CreateRequest(path=path.strip(), kind=kind.casefold()))
        return {"message": f"Created {kind.casefold()}: {path.strip()}.", "data": result}
    rename_match = re.fullmatch(r"rename\s+(.+?)\s+to\s+(.+)", text, flags=re.IGNORECASE)
    if rename_match:
        path, new_name = rename_match.groups()
        result = rename_file_or_folder(RenameRequest(path=path.strip(), new_name=new_name.strip()))
        return {"message": f"Renamed the item to {new_name.strip()}.", "data": result}
    delete_match = re.fullmatch(r"delete\s+(?:file|folder)\s+(.+)", text, flags=re.IGNORECASE)
    if delete_match:
        path = delete_match.group(1).strip()
        result = delete_file_or_folder(DeleteRequest(path=path, confirmed=True))
        return {"message": f"Moved {path} to the Recycle Bin.", "data": result}

    find_match = re.fullmatch(r"(?:find|search for)\s+(?:file\s+)?(.+)", text, flags=re.IGNORECASE)
    if find_match:
        results = search_files(find_match.group(1))
        message = f"Found {len(results)} matching filename(s) in Documents, Downloads, and Desktop." if results else "No matching filenames found in Documents, Downloads, or Desktop."
        return {"message": message, "data": {"files": results}}

    return {
        "message": "I can report diagnostics, control supported apps/volume/brightness, refresh the desktop, manage files in allowed roots, open public sites, search YouTube, and find files.",
        "data": {"accepted": False},
    }


def normalize_local_command(raw_text: str, language: str) -> str:
    """Map common Urdu and Roman Urdu controls to the same named commands."""
    if not language.startswith("ur"):
        return raw_text
    text = re.sub(r"\s+", " ", raw_text.casefold()).strip()
    if any(token in text for token in ("cpu", "ram", "battery", "battry", "betri", "wifi", "wi-fi", "system", "laptop", "سسٹم", "بیٹری", "وائی فائی")):
        if any(token in text for token in ("kitna", "kitni", "batao", "btao", "status", "haal", "hai", "ہے", "کتنا", "کتنی", "بتاؤ")):
            return "system diagnostics"
    if "youtube" in text and any(token in text for token in ("kholo", "khol", "open", "چلاؤ", "کھولو")):
        return "open youtube"
    if "youtube" in text and any(token in text for token in ("search", "dhundo", "dhoondo", "talaash", "سرچ", "تلاش")):
        query = re.sub(r".*?youtube(?:\s+(?:par|pe|for|mein))?\s*", "", text, count=1)
        query = re.sub(r"\b(?:search|karo|kro|kar|dhundo|dhoondo|talaash|batao|btao)\b", " ", query).strip()
        return f"search youtube for {query}" if query else text
    app_names = ("calculator", "notepad", "paint", "photoshop", "premiere", "illustrator", "chrome", "vscode")
    if any(token in text for token in ("kholo", "open", "launch", "چلاؤ", "کھولو")):
        app_name = next((name for name in app_names if name in text), None)
        if app_name:
            return f"launch {app_name}"
    if any(token in text for token in ("band karo", "band kro", "close", "بند کرو", "بند کریں")):
        app_name = next((name for name in app_names if name in text), None)
        if app_name:
            return f"close {app_name}"
    if any(token in text for token in ("focus", "samne lao", "samnay lao", "آگے لاؤ")):
        app_name = next((name for name in app_names if name in text), None)
        if app_name:
            return f"focus {app_name}"
    if "desktop" in text and any(token in text for token in ("refresh", "taaza", "refresh karo")):
        return "refresh desktop"
    volume_number = re.search(r"(?:volume|awaz|آواز)\s*(\d{1,3})", text)
    if volume_number:
        return f"volume set {volume_number.group(1)}"
    if any(token in text for token in ("volume", "awaz", "آواز")):
        if any(token in text for token in ("mute", "khamosh", "خاموش")):
            return "volume mute"
        if any(token in text for token in ("barhao", "barha", "tez", "زیادہ", "بڑھاؤ")):
            return "volume up"
        if any(token in text for token in ("kam karo", "kam kro", "آہستہ", "کم")):
            return "volume down"
    brightness_number = re.search(r"(?:brightness|roshni|روشنی)\s*(?:set\s*)?(\d{1,3})", text)
    if brightness_number:
        return f"brightness set {brightness_number.group(1)}"
    create_folder = re.search(r"(?:folder|directory)\s+(?:banao|bnao|create|بناو|بنائیں)\s+(.+)", text)
    if create_folder:
        return f"create folder {create_folder.group(1).strip()}"
    create_file = re.search(r"(?:file)\s+(?:banao|bnao|create|بناو|بنائیں)\s+(.+)", text)
    if create_file:
        return f"create file {create_file.group(1).strip()}"
    delete_item = re.search(r"(?:delete|hatao|mitao|مٹاؤ|حذف کریں)\s+(?:file|folder|فائل|فولڈر)?\s*(.+)", text)
    if delete_item and any(token in text for token in ("file", "folder", "فائل", "فولڈر")):
        return f"delete file {delete_item.group(1).strip()}"
    if any(token in text for token in ("file", "فائل")) and any(token in text for token in ("dhoond", "dhundo", "find", "search", "تلاش", "ڈھونڈ")):
        query = re.sub(r".*?(?:file|فائل)\s*", "", text, count=1).strip()
        return f"find file {query}" if query else text
    return raw_text


def prompt_mode(text: str) -> str:
    lower = text.casefold()
    if any(word in lower for word in ("code", "python", "javascript", "typescript", "program", "function", "debug", "کود", "کوڈ")):
        return "coding"
    if any(word in lower for word in ("solve", "equation", "math", "engineering", "study guide", "explain", "step by step", "حل کریں", "سمجھائیں")):
        return "academic"
    return "chat"


@app.get("/api/health")
def health():
    return {"ok": True, "service": "CARAXES Local Core", "version": app.version}


@app.get("/api/state")
def get_state():
    with state_lock:
        return dict(state)


@app.post("/api/wake")
def wake(event: WakeEvent):
    with state_lock:
        state["wake_sequence"] += 1
        state["last_wake"] = {"source": event.source, "at": time.time()}
        sequence = state["wake_sequence"]
    focused = False
    try:
        focused = focus_caraxes_window()
    except Exception:
        pass
    return {"ok": True, "wake_sequence": sequence, "window_focused_or_started": focused}


@app.post("/api/focus")
def focus_window():
    return {"ok": focus_caraxes_window()}


@app.post("/api/listener/heartbeat")
def listener_heartbeat():
    with state_lock:
        state["listener_seen_at"] = time.time()
        state["listener_status"] = "online"
        state["listener_error"] = None
    return {"ok": True}


@app.post("/api/listener/status")
def listener_status(update: ListenerStatus):
    with state_lock:
        state["listener_status"] = update.status
        state["listener_error"] = update.error
        if update.status != "online":
            state["listener_seen_at"] = None
    return {"ok": True}


@app.get("/api/diagnostics")
def get_diagnostics():
    return diagnostics()


@app.post("/api/command")
def command(body: Command):
    language = detect_language(body.text)
    result = run_command(normalize_local_command(body.text, language))
    data = result.get("data")
    if isinstance(data, dict) and data.get("accepted") is False:
        try:
            answer, language = generate_answer(body.text, prompt_mode(body.text))
            result = {"message": answer, "data": {"accepted": True, "ai": True}}
        except HTTPException:
            result["message"] = localize_command_message(result["message"], language, data)
    else:
        result["message"] = localize_command_message(result["message"], language, data)
    result["language"] = language
    set_last_action(result["message"], language)
    return result


@app.get("/")
def index():
    if not (DIST / "index.html").is_file():
        return JSONResponse(
            status_code=503,
            content={"detail": "Frontend is not built. See README.md and run npm install, then npm run build in the frontend directory."},
        )
    return FileResponse(DIST / "index.html")


@app.get("/{asset_path:path}")
def assets(asset_path: str):
    candidate = (DIST / asset_path).resolve()
    if DIST.resolve() not in candidate.parents or not candidate.is_file():
        raise HTTPException(status_code=404, detail="Not found")
    return FileResponse(candidate)
