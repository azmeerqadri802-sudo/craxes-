# CARAXES — The Blood Wyrm

CARAXES is a local Windows desktop command center built on the existing FastAPI and Three.js app. The upgrade preserves the original `/api/*`, `/syrax/roster`, and `/meleys/diagnostics` routes, adds the Tessarion Adobe module, language-aware replies and speech, bounded file/app controls, and Windows sign-in startup support.

## Modules and routes

| Module | Main routes | Purpose |
| --- | --- | --- |
| Syrax | `GET /syrax/roster` | 16-dragon registry and dashboard coordination |
| Meleys | `GET /meleys/diagnostics`, `GET /balerion/system` | CPU, memory, battery, network, brightness, and volume status |
| Caraxes | `POST /caraxes/code`, `POST /caraxes/learn` | Complete-code and step-by-step academic responses |
| Dreamfyre | `POST /dreamfyre/ask` | Language detection and local/configured AI requests |
| Moondancer | `POST /moondancer/prepare` | English/Urdu speech settings for installed Windows voices |
| Balerion | `/balerion/apps/*`, `/balerion/volume`, `/balerion/brightness`, `/balerion/desktop/refresh`, `/balerion/window/focus` | Named application and desktop actions |
| Tyraxes | `/tyraxes/files/create`, `/rename`, `/delete`, `GET /tyraxes/roots` | File operations inside configured user-owned folders |
| Tessarion | `/tessarion/premiere/*`, `/tessarion/broll/generate`, `/tessarion/after-effects/*`, `/tessarion/photoshop/*`, `/tessarion/illustrator/*` | Adobe edit plans, UXP panel, JSX hooks, B-roll generation |

The earlier endpoints remain available, including `GET /api/health`, `/api/state`, `/api/diagnostics`, `POST /api/wake`, and `POST /api/command`.

## Windows desktop build

The repository workflow at `.github/workflows/build-windows.yml` builds a portable x64 `CARAXES.exe` with the frontend, offline wake model, Adobe hooks, Premiere UXP panel source, and desktop dependencies. Download it from the workflow run's **Artifacts** section. Windows WebView2 Runtime and microphone permission are required.

When CARAXES is open, the offline listener waits for **Dracarys**, brings the dashboard window forward, then captures one command. The bundled Vosk model recognizes English wake/command speech; typed requests and AI replies detect English, Urdu script, and Roman Urdu. Speech playback uses the matching installed Windows voice when available.

Enable startup for the current Windows user from a terminal:

```powershell
CARAXES.exe --enable-autostart
```

Or, from the source checkout, run `py scripts\enable_autostart.py --enable`. Startup launches the API and wake listener quietly; speaking “Dracarys” opens or focuses the dashboard. To disable it, run `CARAXES.exe --disable-autostart` or `py scripts\enable_autostart.py --disable`.

## AI setup

Dreamfyre defaults to an OpenAI-compatible local server at `http://127.0.0.1:11434/v1` with model `qwen2.5-coder:7b`. For Ollama, start the service and pull that model. To use another compatible server, set these environment variables before launching CARAXES:

```powershell
$env:CARAXES_LLM_BASE_URL = "https://your-provider.example/v1"
$env:CARAXES_LLM_MODEL = "your-model-name"
$env:CARAXES_LLM_API_KEY = "your-key"
```

Without a running model, named local commands and diagnostics still work; generative chat, code, and academic answers return an unavailable response.

## Tessarion and Adobe

Premiere automation is provided as a UXP panel for Premiere Pro 25.6 or later. Enable Premiere developer mode, open the bundled `backend/modules/adobe_uxp/tessarion_premiere/manifest.json` in Adobe UXP Developer Tool, then load the panel. Analyze silence with `/tessarion/premiere/analyze-silence`, create or render a cut plan, and load the returned JSON manifest in the panel. The panel confirms timeline edits and groups them into an undo transaction; use Premiere Undo to revert. An interior silence cut that spans one continuous clip is represented with cut markers when the sequence API cannot safely split that clip automatically.

FFmpeg and FFprobe must be installed and available on `PATH` for silence detection and media rendering. The render endpoint writes a new file and leaves the source unchanged. Sound effects and transitions are placed at the resulting edit points by the UXP panel.

Image generation is opt-in. Configure an OpenAI-compatible image endpoint that returns PNG `data[0].b64_json` data:

```powershell
$env:CARAXES_IMAGEGEN_URL = "https://your-provider.example/v1/images/generations"
$env:CARAXES_IMAGEGEN_MODEL = "your-image-model"
$env:CARAXES_IMAGEGEN_API_KEY = "your-key"
```

Then call `POST /tessarion/broll/generate` with up to four prompts. The route saves local PNG files and writes a Premiere manifest; load the manifest in the panel to import and place them. The Photoshop and Illustrator endpoints create ExtendScript files for the selected local asset. Open the destination document and run the generated script inside the relevant Adobe app. After Effects motion graphics likewise generate a JSX script; review its composition settings before rendering.

Official Adobe references: [Premiere UXP API](https://developer.adobe.com/premiere-pro/uxp/), [Premiere UXP plugin guide](https://developer.adobe.com/premiere-pro/uxp/plugins/), and [Photoshop UXP guide](https://developer.adobe.com/photoshop/uxp/guides/).

## Native actions and safety boundaries

CARAXES listens only on loopback (`127.0.0.1`). It does not expose arbitrary shell execution, Python evaluation, administrator elevation, or unrestricted remote control. Apps are started from known Windows/Adobe folders or a user-provided `.exe` inside trusted roots. Closing a process requires confirmation and sends `WM_CLOSE` so the application can prompt to save. File creation and rename stay within allowed roots; delete requires confirmation and moves the item to the Recycle Bin.

By default, allowed file roots are the current user's home folder. To grant more folders, set `CARAXES_ALLOWED_ROOTS` to a semicolon-separated list of existing paths before launch, for example:

```powershell
$env:CARAXES_ALLOWED_ROOTS = "C:\Users\azmee;D:\Projects"
```

Wi-Fi status reports local network interfaces. Brightness control depends on Windows display WMI support; volume control uses Windows Core Audio. These capabilities may be unavailable on some hardware.

## Build from source

```powershell
py -m pip install -r desktop-requirements.txt
cd frontend
npm install
npm run build
cd ..
py desktop.py
```

For the local API without the desktop shell, install `backend/requirements.txt` and run `py -m uvicorn backend.main:app --host 127.0.0.1 --port 8765`.
