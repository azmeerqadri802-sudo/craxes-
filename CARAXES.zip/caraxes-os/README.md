# CARAXES — The Blood Wyrm

CARAXES is a local-first desktop command-center prototype: a cinematic Three.js dragonpit, a FastAPI service on loopback, and an optional offline Vosk wake-word listener. The frontend includes all 15 requested dragon identities and role labels. The role list is a command-center registry; it does not imply that every named subsystem is implemented.

## What works

- Fifteen procedural Three.js dragon silhouettes enter the stage in sequence, with animated wings, ember/fire particles, and a name-and-role reveal.
- The **Awaken Core** button replays the entrance. A short synthesized cue plays when the browser permits audio; browsers generally require one user gesture before audio playback.
- Live CPU, memory, battery, and network-interface diagnostics from `psutil`.
- Typed or spoken named commands: diagnostics; open YouTube, Google, Wikipedia, or a public HTTPS page; search YouTube; launch the small platform app allowlist; and search filenames in Documents, Downloads, and Desktop.
- The Windows desktop executable starts the local-only microphone listener on launch. It detects **“Dracarys”** offline, notifies the open dashboard, then captures one command. Say “Dracarys,” pause, then speak the command. The executable bundles Vosk's small English model and its audio dependencies; no model download or separate Python setup is needed.

Example commands:

```text
diagnostics
open youtube
search youtube for ambient music
launch calculator
find file budget
open https://example.com
```

## Run on Windows

## Windows desktop executable

`desktop.py` wraps the local API and dashboard in a native WebView2 window. The GitHub Actions workflow at `.github/workflows/build-windows.yml` produces a portable `CARAXES.exe` artifact for Windows x64 when manually run or when a `v*` tag is pushed. Download it from that workflow run's **Artifacts** section. It is not an Android APK or an installer. Windows WebView2 Runtime is required; pywebview uses Edge WebView2 on Windows ([pywebview installation notes](https://github.com/r0x0r/pywebview/blob/master/docs/guide/installation.md)).

The executable includes the UI, named local commands, offline Vosk model, and wake listener. If the pill shows `LISTENER ERROR`, hover it to see whether Windows could not open a microphone; check Windows **Settings → Privacy & security → Microphone** and select an available input device.

To run the desktop host locally, install the desktop dependencies and build the frontend first:

```powershell
py -m pip install -r desktop-requirements.txt
cd frontend
npm install
npm run build
cd ..
py desktop.py
```

The production `.exe` is built with PyInstaller and includes the generated frontend files ([PyInstaller usage](https://pyinstaller.org/en/latest/usage.html)).

## Run the source web app

Use three PowerShell windows from this directory. Install dependencies once:

Use Node.js 20.19+ or 22.12+ for the pinned Vite 8 toolchain, as listed in the [official Vite guide](https://vite.dev/guide/). The package versions are pinned to Three.js 0.186.0 and Vite 8.3.0, following the projects' [release lists](https://github.com/mrdoob/three.js/releases) and [Vite release list](https://github.com/vitejs/vite/releases).

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r backend\requirements.txt
cd frontend
npm install
npm run build
cd ..
```

Start the local API and built dashboard in the first window:

```powershell
.\.venv\Scripts\Activate.ps1
py -m uvicorn backend.main:app --host 127.0.0.1 --port 8765
```

Open [http://127.0.0.1:8765](http://127.0.0.1:8765). For frontend development, run `npm run dev` inside `frontend` in another window and open [http://127.0.0.1:5173](http://127.0.0.1:5173); Vite proxies `/api` calls to FastAPI.

To enable the wake listener, install its optional packages and obtain an offline language model from the [official Vosk model catalog](https://alphacephei.com/vosk/models):

```powershell
.\.venv\Scripts\Activate.ps1
pip install -r scripts\requirements.txt
$env:CARAXES_VOSK_MODEL = "C:\path\to\your\unpacked-vosk-model"
python scripts\wake_listener.py
```

To launch it hidden in the background instead, with the model path set, run `powershell -ExecutionPolicy Bypass -File scripts\start_listener.ps1 -ModelPath "C:\path\to\your\unpacked-vosk-model"`. Stop only that listener with `powershell -ExecutionPolicy Bypass -File scripts\stop_listener.ps1`. Its standard output and errors are written to `scripts\wake_listener.stdout.log` and `scripts\wake_listener.stderr.log`.

The model is selected by you and stays on disk; listener audio is processed locally and is not uploaded. Keep the dashboard and API running while the listener is active. Microphone access and a compatible audio input device are required.

## Command and security boundary

The API binds to `127.0.0.1` and applies host/origin checks. It has no arbitrary shell endpoint, Python evaluator, admin elevation, browser scraping, or general-purpose computer-control hook. App launching is an explicit `shell=False` allowlist. URL opening requires public HTTPS and rejects literal private/local addresses. File search returns filenames only from the three named folders, with traversal and result limits. Diagnostics report active network interfaces rather than probing external hosts.

This starter does not send WhatsApp messages, place calls, send email, change firewall rules, clear caches or system junk, encrypt/store secrets, generate media, run calendar jobs, or provide an AI model. Those roles remain visual entries until a separate, reviewed integration is added. Messages and other external actions should require a review step in any future integration.

The API surface is `GET /api/health`, `GET /api/state`, `GET /api/diagnostics`, `POST /api/wake`, `POST /api/listener/heartbeat`, and `POST /api/command`.

Do not expose the API port to a network or use it as an administrator. Loopback limits remote access; it is not a per-user authentication boundary against other software already running in your account.

## Structure

```text
caraxes-os/
├── backend/
│   ├── main.py
│   └── requirements.txt
├── frontend/
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   └── src/
│       ├── main.js
│       └── style.css
└── scripts/
    ├── requirements.txt
    └── wake_listener.py
```

## The fifteen module identities

| Dragon | Role shown in the command center |
| --- | --- |
| Caraxes | Core brain · advanced code execution |
| Syrax | Master control UI · visual dashboard |
| Vhagar | Heavy security · privacy shields |
| Balerion | System automation · root macros |
| Meleys | Speed optimization · performance |
| Vermithor | Database vault · local retrieval |
| Silverwing | UI/UX aesthetics · dynamic themes |
| Seasmoke | Network · APIs · web hooks |
| Sunfyre | Media rendering · graphics pipeline |
| Dreamfyre | AI prompt processor · context |
| Vermax | Task scheduler · reminders |
| Arrax | Encryption guard · privacy filters |
| Tyraxes | File management · organization |
| Moondancer | Voice · audio synchronization |
| The Cannibal | Garbage collection · cleanup |
